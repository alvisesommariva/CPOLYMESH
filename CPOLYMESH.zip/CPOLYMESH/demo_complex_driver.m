
function demo_complex_driver(example,degV,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo describing pointsets and their Lebesgue constants over a complex
% domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise 
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% L. Leokadia Białas-Cież, 
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 1, 2023
%--------------------------------------------------------------------------

% Complex set:
%     example 1: 'sun';
%     example 2: 'polygon';
%     example 3: 'cardioid';
%     example 4: 'curvpolygon';
%     example 5: 'uniondisks';
%     example 6: 'lune';
%     example 7: 'hypocycloid';
%     example 8: 'epicycloid';
%     example 9: 'epitrochoid';
%     example 10: 'limacon';
%     example 11: 'ellipse';
%     example 12: 'lissajous';
%     example 13: 'deltoid'
%     example 14: 'rhodonea'
%     example 15: 'habenicht_clover';
%     example 16: 'egg'
%     example 17: 'bifolium'
%     example 18: 'torpedo'

if nargin < 1, example=2; end

% Interpolation degree.
if nargin < 2, degV=1:50; end

% Admissible mesh "m" factor (linked to Lebesgue constant estimate)
% The higher the better estimate but also more time consuming.
if nargin < 3, m=4; end



% ....................... MAIN CODE BELOW .......................

% Define domain properties.
domain=define_domain(example);

% Compute Lebesgue constants.
lebV_cell={}; % cell containing Lebesgue constant vectors, for each alg.
lebV_REE_cell={}; % cell containing Leb. constant REE vectors, for each alg.
zAM_hist_cell={}; % cell of cells of AM.
pts_hist_cell={}; % cell of cells of pts.

% Choose "leja" between 0: afek, 1: discrete Leja, 2: pseudo Leja. 
% Setting "leja" equal to 3, will test an example with Least-Squares.
% It will make experiments with all these choices.

for leja=0:3
    lebV=[];
    REEV=[];
    zAM_hist_loc={};
    pts_hist_loc={};
    for deg=degV
        [lebL,ptsL,zAML,REEL]=demo_complex(domain,leja,deg,m);

        % local data storage 
        lebV=[lebV; lebL];
        REEV=[REEV; REEL];
        zAM_hist_loc{end+1}=zAML;
        pts_hist_loc{end+1}=ptsL;
    end

    % global data storage 
    lebV_cell{end+1}=lebV;
    lebV_REE_cell{end+1}=REEV;
    zAM_hist_loc{end+1}=zAM_hist_loc;
    pts_hist_cell{end+1}=pts_hist_loc;
end

% useful for plotting features
set2plot=1; % 1: AFEK, 2: DLP, 3: PLP
setL=pts_hist_cell{set2plot};
ptsL=setL{end};

% plots: 
clear_figure(1);
figure(1)
gainsboro=[220 220 220]/256;
[X,dbox]=test_points(domain,20);
plot(real(X),imag(X),'o','color',gainsboro, ...
    'MarkerSize',1); hold on;
X=[]; % X may be a large set and cause memory troubles.
plot(real(zAML),imag(zAML),'b.','MarkerSize',4); 
xV=real(zAML); xV=[xV; xV(1)];
yV=imag(zAML); yV=[yV; yV(1)];
% plot(xV,yV,'-','color',gainsboro,'MarkerSize',1); hold on;
plot(real(ptsL),imag(ptsL),'go','MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',6);
axis equal;
axis off;
axis tight;
set(gca,'xtick',[])
set(gca,'ytick',[])
hold off

saveas(gcf,'figure1.eps');



% PLOT LEBESGUE CONSTANTS
clear_figure(2)
figure(2)

plot(degV(:),lebV_cell{1},'r-','LineWidth',3); hold on;
plot(degV(:),lebV_cell{1},'ro','LineWidth',3); hold on;
plot(degV(:),lebV_cell{2},'b-','LineWidth',3); hold on;
plot(degV(:),lebV_cell{2},'bo','LineWidth',3); hold on;
violet=[0.4940, 0.1840, 0.5560];
plot(degV(:),lebV_cell{3},'-','color',violet,'LineWidth',3); hold on;
plot(degV(:),lebV_cell{3},'o','color',violet,'LineWidth',3); hold on;
salmon=[250 128 114]/256;
plot(degV(:),lebV_cell{4},'-.','color',salmon,'LineWidth',3); hold on;
plot(degV(:),lebV_cell{4},'o','color',salmon,'LineWidth',3); hold on;
% legend('AFEK','DLP','PLP');

plot_lebs(degV,lebV_cell{1},lebV_REE_cell{1},'r'); hold on;
plot_lebs(degV,lebV_cell{2},lebV_REE_cell{2},'b'); hold on;
plot_lebs(degV,lebV_cell{3},lebV_REE_cell{3},violet); hold on;
plot_lebs(degV,lebV_cell{3},lebV_REE_cell{4},salmon); hold on;
grid on;
hold off;
saveas(gcf,'figure2.eps');


fprintf(2,'\n \t .............. Final remarks .................\n ');
fprintf(2,'\n \t 0. We have saved the pictures of the region as');
fprintf(2,'\n \t    well as of the Lebesgue costants in two files');
fprintf(2,'\n \t    named resp. ''figure2.eps'' and ''figure2.eps''. \n');
fprintf(2,'\n \t 1. In fig 1:')
fprintf(2,'\n \t    * grey: complex region');
fprintf(2,'\n \t    * blue dots: AM')
fprintf(2,'\n \t    * green: ')
switch set2plot
    case 1
       fig1pts_str='Approximate Fekete Points';
    case 2
        fig1pts_str='Discrete Leja Points';
     case 3
        fig1pts_str='Pseudo Leja Points';
     case 4
        fig1pts_str='Least-Square Points';
end
fprintf(2,fig1pts_str);

fprintf(2,'\n \n \t 2. In fig 2:')
fprintf(2,'\n \t    * salmon: Least-Squares')
fprintf(2,'\n \t              -> pointset is AM of degree: %3.0f',degV(end));
fprintf(2,'\n \t                 with factor m: %3.0f',m);
fprintf(2,'\n \t    * red: Approx. Fekete Points ')
fprintf(2,'\n \t    * blue: Discrete Leja Points ')
fprintf(2,'\n \t    * violet: Pseudo Leja Points')
fprintf(2,'\n \n \t 3. The colored strip above the line describes ');
fprintf(2,'\n \t    the region in which the exact value of the '); 
fprintf(2,'\n \t    Lebesgue constant will lie. \t    ');
fprintf('\n \t ..............................................\n \n ');


function plot_lebs(degV,lebV,lebV_REE,c1)

degV=degV(:);
lebVL=lebV(:,1); lebV_max=lebVL.*(1+lebV_REE); 

stripe=[degV lebVL; flipud(degV) flipud(lebV_max)];
stripe(end+1,:)=stripe(1,:);

fill(stripe(:,1),stripe(:,2),c1,'FaceAlpha', 0.1, 'EdgeColor', 'none',...
    'HandleVisibility','off'); 






function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end




