
function demo_complex_driver(example,degV,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo describing pointsets and their Lebesgue constants over a complex
% domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

% Complex set:
%     example 1: 'sun';
%     example 2: 'polygon';
%     example 3: 'cardioid';
%     example 4: 'curvpolygon';
%     example 5: 'uniondisks';
%     example 6: 'lune';
%     example 7: 'hypocycloid';
%     example 8: 'epicycloid';
%     example 9: 'epitrochoid';
%     example 10: 'limacon';
%     example 11: 'ellipse';
%     example 12: 'lissajous';
%     example 13: 'deltoid'
%     example 14: 'rhodonea'
%     example 15: 'habenicht_clover';
%     example 16: 'egg'
%     example 17: 'bifolium'
%     example 18: 'torpedo'

if nargin < 1, example=2; end

% Interpolation degree.
if nargin < 2, degV=1:50; end

% Admissible mesh "m" factor (linked to Lebesgue constant estimate)
% The higher the better estimate but also more time consuming.
if nargin < 3, m=4; end



% ....................... MAIN CODE BELOW .......................

% Define domain properties.
domain=define_domain(example);

% Compute Lebesgue constants.
lebV_cell={}; % cell containing Lebesgue constant vectors, for each alg.
lebV_REE_cell={}; % cell containing Leb. constant REE vectors, for each alg.
zAM_hist_cell={}; % cell of cells of AM.
pts_hist_cell={}; % cell of cells of pts.

% Choose "leja" between 0: afek, 1: discrete Leja, 2: pseudo Leja. 
% Setting "leja" equal to 3, will test an example with Least-Squares.
% It will make experiments with all these choices.

for leja=0:3
    lebV=[];
    REEV=[];
    zAM_hist_loc={};
    pts_hist_loc={};
    for deg=degV
        [lebL,ptsL,zAML,REEL]=demo_complex(domain,leja,deg,m);

        % local data storage 
        lebV=[lebV; lebL];
        REEV=[REEV; REEL];
        zAM_hist_loc{end+1}=zAML;
        pts_hist_loc{end+1}=ptsL;
    end

    % global data storage 
    lebV_cell{end+1}=lebV;
    lebV_REE_cell{end+1}=REEV;
    zAM_hist_loc{end+1}=zAM_hist_loc;
    pts_hist_cell{end+1}=pts_hist_loc;
end

% argument below: 1: AFEK, 2: DLP, 3: PLP
% useful for plotting features
setL=pts_hist_cell{1};
ptsL=setL{end};

% Plots
clear_figure(1);
figure(1)
gainsboro=[220 220 220]/256;
plot(real(zAML),imag(zAML),'b.','MarkerSize',4); hold on;
xV=real(zAML); xV=[xV; xV(1)];
yV=imag(zAML); yV=[yV; yV(1)];
% plot(xV,yV,'-','color',gainsboro,'MarkerSize',1); hold on;
plot(real(ptsL),imag(ptsL),'go','MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',6);
axis equal;
hold off


% PLOT LEBESGUE CONSTANTS
clear_figure(2)
figure(2)

plot(degV(:),lebV_cell{1},'r-','LineWidth',3); hold on;
plot(degV(:),lebV_cell{1},'ro','LineWidth',3); hold on;
plot(degV(:),lebV_cell{2},'b-','LineWidth',3); hold on;
plot(degV(:),lebV_cell{2},'bo','LineWidth',3); hold on;
violet=[0.4940, 0.1840, 0.5560];
plot(degV(:),lebV_cell{3},'-','color',violet,'LineWidth',3); hold on;
plot(degV(:),lebV_cell{3},'o','color',violet,'LineWidth',3); hold on;
salmon=[250 128 114]/256;
plot(degV(:),lebV_cell{4},'-.','color',salmon,'LineWidth',3); hold on;
plot(degV(:),lebV_cell{4},'o','color',salmon,'LineWidth',3); hold on;
% legend('AFEK','DLP','PLP');

plot_lebs(degV,lebV_cell{1},lebV_REE_cell{1},'r'); hold on;
plot_lebs(degV,lebV_cell{2},lebV_REE_cell{2},'b'); hold on;
plot_lebs(degV,lebV_cell{3},lebV_REE_cell{3},violet); hold on;
plot_lebs(degV,lebV_cell{3},lebV_REE_cell{4},salmon); hold on;
grid on;
hold off;

fprintf('\n \t In fig 2:')
fprintf('\n \t red: AFEK, blue: DLP, violet: PLP \n \n')




function plot_lebs(degV,lebV,lebV_REE,c1)

degV=degV(:);
lebVL=lebV(:,1); lebV_max=lebVL.*(1+lebV_REE); 

stripe=[degV lebVL; flipud(degV) flipud(lebV_max)];
stripe(end+1,:)=stripe(1,:);

fill(stripe(:,1),stripe(:,2),c1,'FaceAlpha', 0.1, 'EdgeColor', 'none',...
    'HandleVisibility','off'); 






function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end




