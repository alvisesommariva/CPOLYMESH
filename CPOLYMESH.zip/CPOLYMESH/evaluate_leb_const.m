
function [leb_constant,zAM,C]=evaluate_leb_const(domain,pts,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Evaluation of the Lebesgue constant via AM on complex domains.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: domain structure (dependent on the domain, see "define_domain.m");
% pts: interpolation/least square points;
% deg: interpolation degree;
% m: positive integer for computing the Lebesgue constant; the higher than
%    is the most precise but also more time consuming (use, e.g. m=4).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% leb_constant: Lebesgue constant of interpolation set,
% -> leb_constant(1): rough approximation,
% -> leb_constant(2): fine approximation;
% zAM: admissible mesh for this domain at degree deg;
% C: admissible mesh constant.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

% 0: SET DEFAULTS.
if nargin < 4, m=4; end

zC=domain.zC; zR=domain.zR; % disk including the domain (center,
% radius)

% 1. DEFINE AM FOR LEB. CONST. EVALUATION.
[zAM,C]=complex_AM(domain,deg,m);

% 2. COMPUTE VANDERMONDE MATRIX AT AM.
leb_constant = cwamleb(deg,pts,zAM,domain);





function leb = cwamleb(deg,pts,cmesh,domain)


%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes the Lebesgue constant of least-squares polynomial fitting   
% on "pts", using the control mesh "cmesh".
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
%--------------------------------------------------------------------------

[Q,R1,R2]=cwamdop(deg,pts,domain);
DOP=cwamdopeval(deg,R1,R2,cmesh,domain);
leb=norm(Q*DOP',1);





function [Q,R1,R2] = cwamdop(deg,pts,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes discrete orthogonal polynomials up to degree deg 
% on the mesh wam: Q is the corresponding orthogonal matrix, 
% inv(R1)*inv(R2) the orthogonalization matrix 
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
%--------------------------------------------------------------------------

V=gen_vandermonde_matrix(pts,deg,domain.zC,domain.zR);
[Q1,R1]=qr(V,0);
[Q,R2]=qr(V/R1,0);





function DOP = cwamdopeval(deg,R1,R2,pts,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes the Vandermonde matrix of degree deg at the points pts 
% in a discrete orthogonal polynomial basis  
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
%--------------------------------------------------------------------------

W=gen_vandermonde_matrix(pts,deg,domain.zC,domain.zR);
DOP=(W/R1)/R2;

