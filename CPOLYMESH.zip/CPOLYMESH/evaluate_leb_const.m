
function [leb_constant,zAM,C,domain]=evaluate_leb_const(domain,pts,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Evaluation of the Lebesgue constant via AM on complex domains.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: domain structure (dependent on the domain, see "define_domain.m");
% pts: interpolation/least square points;
% deg: interpolation degree;
% m: positive integer for computing the Lebesgue constant; the higher than
%    is the most precise but also more time consuming (use, e.g. m=4).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% leb_constant: Lebesgue constant of interpolation set,
% -> leb_constant(1): rough approximation,
% -> leb_constant(2): fine approximation;
% zAM: admissible mesh for this domain at degree deg;
% C: admissible mesh constant.
% domain: structure defining the domain and some additional information as
%    a disk B(zC,zR) containing the domain, where
%    1. "zC" is stored in "domain.zC",
%    2. "zR" is stored in "domain.zR".
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% L. Leokadia Białas-Cież,
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 4, 2023
%--------------------------------------------------------------------------


% 0: SET DEFAULTS.
if nargin < 4, m=4; end

% 1. DEFINE AM FOR LEB. CONST. EVALUATION.
[zAM,C]=complex_AM(domain,deg,m);

% Determine disk "B(zC,zR)" including the domain.
[zC,zR]=disk_enclosing_region(domain);
domain.zC=zC; domain.zR=zR; % storing information in "domain" struct.

% 2. COMPUTE VANDERMONDE MATRIX AT AM.
leb_constant = cwamleb(deg,pts,zAM,domain);



















