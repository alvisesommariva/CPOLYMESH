
function domain=define_domain(example)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Definition of complex sets structures.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% Example: parameter that chooses a complex set:
%
%     example 1: 'sun';
%     example 2: 'polygon';
%     example 3: 'cardioid';
%     example 4: 'curvpolygon';
%     example 5: 'uniondisks';
%     example 6: 'lune';
%     example 7: 'hypocycloid';
%     example 8: 'epicycloid';
%     example 9: 'epitrochoid';
%     example 10: 'limacon';
%     example 11: 'ellipse';
%     example 12: 'lissajous';
%     example 13: 'deltoid'
%     example 14: 'rhodonea'
%     example 15: 'habenicht_clover';
%     example 16: 'egg'
%     example 17: 'bifolium'
%     example 18: 'torpedo'
%
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% domain: the set is defined by its structure, containing all the variables
%     useful for its definition.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 24, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

switch example
    case 1
        domain.name='sun';
        domain.center=0;
        domain.radius=1;
        domain.beams=8;
        domain.beamslength=0.5;

    case 2
        domain.name='polygon';
        sub_example=9; % see "gallery_polygons" below.
        [domain.vertices,domain.string]=gallery_polygons(sub_example);

    case 3
        domain.name='cardioid';

    case 4
        domain.name='curvpolygon';
        sub_example=3; % see "gallery_curvpolygon" below.
        [Sx,Sy,vertices,domain_str]=gallery_curvpolygon(sub_example);
        domain.Sx=Sx;
        domain.Sy=Sy;
        domain.vertices=vertices;
        domain.string=domain_str;

    case 5
        domain.name='uniondisks';
        sub_example=2; % see "gallery_uniondisks" below.
        [centers,rs]=gallery_uniondisks(sub_example);
        domain.centers=centers;
        domain.rs=rs;

    case 6
        domain.name='lune';
        domain.centers=[-1 1]';
        domain.rs=[1.5 1.5]';

    case 7
        % NOTE: on the parameters defining the boundary;
        % 1. choose "b" so that "a/b" is natural, thus "a>b".
        % 2. a deltoid is obtained by setting "a=3", "b=1";

        domain.name='hypocycloid';
        domain.a=9;
        domain.b=1;

    case 8
        domain.name='epicycloid';
        domain.r=3;
        domain.R=9; % choose "R" so that "R/r" is natural.

    case 9
        % NOTE: on the parameters defining the boundary;
        % r,R: parameters defining the hypocycloid, with r < R,
        %      R multiple of r.
        domain.name='epitrochoid';
        domain.r=2;
        domain.R=16; % choose "R" so that "R/r" is natural.
        domain.d=1;

    case 10
        % NOTE: on the parameters defining the boundary;
        %      the limacon is defined as 
        %              z(t)=(b/2)+a*exp(i*t)+(b/2)*exp(2*i*t);
        % 1. for avoiding auto-intersections choose "b <= a";
        % 2. the domain is convex if "a >= 2*b";
        % 3. the domain is  concave if "b <= a < 2*b".
        domain.name='limacon';
        domain.a=7;
        domain.b=5;

    case 11
        domain.name='ellipse';
        domain.a=6;
        domain.b=3;

    case 12
        % NOTE:
        % domain.aV,domain.wV,domain.phiV: parameters defining the boundary,
        % i.e. z(t)=x(t)+i*y(t) with
        %        x(t)=aV(1)*sin(wV(1)+phiV(1)),
        %        y(t)=aV(2)*sin(wV(2)+phiV(2))
        % with wV vector of positive integers.
        domain.name='lissajous';
        domain.aV=[1 1];
        domain.wV=[1 2];
        domain.phiV=[0 0];

    case 13
        % NOTE:
        % deltoid: fixed boundary, no parameters are needed
        domain.name='deltoid';

    case 14
        % NOTE:
        % rhodonea: z(t)=a*cos(k*t)*exp(i*t), t in [0,2*pi]
        % 1. choose "k > 0" as integer.
        % 2. choose "a > 0"
        % * https://en.wikipedia.org/wiki/Rose_(mathematics)
        domain.name='rhodonea';
        domain.a=1;
        domain.k=4;

    case 15
        % NOTE:
        % n: parameter defining the boundary, with
        %          z(t)=(1+cos(n*t)+(sin(n*t))^2).*exp(i*t),  t in [0,2*pi]
        %      with "n > 0" integer; e.g. choose "n=3"
        % It is a clover like domain.
        domain.name='habenicht_clover';
        domain.n=3;

    case 16
        % NOTE:
        % n: parameter defining the boundary, with
        %          z(t)=a*(cos(t))^n).*exp(i*t),  t in [0,2*pi]
        %      with "n > 0" integer; e.g. choose "n=3"
        domain.name='egg';
        domain.a=1;
        domain.n=3;

      case 17
        % NOTE:
        % the boundary is z(t)=cos(t).*(sin(t))^2).*exp(i*t),  t in [0,2*pi]
        domain.name='bifolium';

      case 18
        % NOTE:
        % the boundary is z(t)=a*cos(t).*cos(2*t).*exp(i*t),  t in [0,2*pi]
        domain.name='torpedo';
        domain.a=1;
end

[domain.zC,domain.zR]=disk_enclosing_set(domain);













function [zC,zR]=disk_enclosing_set(domain)

zAM=complex_AM(domain,10,4);
zC=mean(zAM);
zR=max(abs(zAM-zC));




function [vertices,domain_str]=gallery_polygons(example)

% IMPORTANT: first and last vertices are equal.

P=[];

switch example

    case 1
        domain_str='UNIT SQUARE [0,1]^2';
        k=1;
        vertices=k*[0 0; 1 0; 1 1; 0 1];

    case 2
        domain_str='CONVEX POLYGON';
        vertices=[0.1 0; 0.7 0.2; 1 0.5; 0.75 0.85; 0.5 1; 0 0.25];

    case 3
        domain_str='NON CONVEX POLYGON';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];

    case 4
        domain_str='Polygon';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 4; 2 4; 0 3; 1 2];

    case 5
        domain_str='Polygon';
        vertices=(1/4)*[0 0; 1 2; 2 0; 3 2; 4 0; 4 4; 3 2; 2 4; ...
            1 2; 0 4];

    case 6
        domain_str='UNIT SQUARE [-1,1]^2';
        vertices=[-1 -1; 1 -1; 1 1; -1 1];

    case 7
        domain_str='UNIT TRIANGLE: [0 0; 1 0; 1 1]';
        vertices=[0 0; 1 0; 1 1];

    case 8
        domain_str='PSEUDO-CIRCLE';
        N=20; a=0; b=2*pi;
        h=(b-a)/N; theta=(a:h:b-h)';
        x=cos(theta); y=sin(theta);
        x=0.5*x+0.5; y=0.5*y+0.5;
        vertices=[x y];

    case 9 % domain M
        domain_str='M';
         vertices=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];

    case 10

        X=[
            -191.0000 -104.0000
            -200.5000 -104.5000
            -209.5000 -105.5000
            -218.5000 -106.5000
            -226.5000 -108.5000
            -235.0000 -110.0000
            -243.5000 -111.5000
            -251.5000 -113.5000
            -258.5000 -116.5000
            -266.5000 -118.5000
            -274.5000 -120.5000
            -281.5000 -123.5000
            -289.0000 -126.0000
            -296.5000 -128.5000
            -303.5000 -131.5000
            -310.5000 -134.5000
            -318.0000 -137.0000
            -325.0000 -140.0000
            -332.0000 -143.0000
            -334.0000 -136.0000
            -334.0000 -126.0000
            -334.0000 -116.0000
            -341.5000 -113.5000
            -351.5000 -113.5000
            -361.5000 -113.5000
            -371.5000 -113.5000
            -381.5000 -113.5000
            -391.5000 -113.5000
            -401.5000 -113.5000
            -411.5000 -113.5000
            -421.5000 -113.5000
            -431.5000 -113.5000
            -441.5000 -113.5000
            -451.5000 -113.5000
            -461.5000 -113.5000
            -471.5000 -113.5000
            -478.0000 -117.0000
            -477.0000 -126.0000
            -468.5000 -127.5000
            -459.5000 -128.5000
            -450.5000 -129.5000
            -441.5000 -130.5000
            -434.0000 -133.0000
            -427.0000 -136.0000
            -421.0000 -140.0000
            -416.0000 -145.0000
            -412.0000 -151.0000
            -409.0000 -158.0000
            -407.0000 -166.0000
            -407.0000 -176.0000
            -406.0000 -185.0000
            -406.0000 -195.0000
            -406.0000 -205.0000
            -406.0000 -215.0000
            -406.0000 -225.0000
            -406.0000 -235.0000
            -406.0000 -245.0000
            -406.0000 -255.0000
            -406.0000 -265.0000
            -406.0000 -275.0000
            -406.0000 -285.0000
            -406.0000 -295.0000
            -406.0000 -305.0000
            -406.0000 -315.0000
            -406.0000 -325.0000
            -406.0000 -335.0000
            -406.0000 -345.0000
            -406.0000 -355.0000
            -406.0000 -365.0000
            -406.0000 -375.0000
            -406.0000 -385.0000
            -406.0000 -395.0000
            -406.0000 -405.0000
            -406.0000 -415.0000
            -406.0000 -425.0000
            -406.0000 -435.0000
            -406.0000 -445.0000
            -406.0000 -455.0000
            -406.0000 -465.0000
            -406.0000 -475.0000
            -406.0000 -485.0000
            -406.0000 -495.0000
            -406.0000 -505.0000
            -406.0000 -515.0000
            -406.0000 -525.0000
            -406.0000 -535.0000
            -406.5000 -544.5000
            -407.0000 -554.0000
            -408.0000 -563.0000
            -410.0000 -571.0000
            -413.0000 -578.0000
            -417.5000 -583.5000
            -423.0000 -588.0000
            -429.5000 -591.5000
            -436.5000 -594.5000
            -444.5000 -596.5000
            -453.0000 -598.0000
            -462.5000 -598.5000
            -471.5000 -599.5000
            -478.0000 -603.0000
            -477.0000 -612.0000
            -468.5000 -613.5000
            -458.5000 -613.5000
            -448.5000 -613.5000
            -438.5000 -613.5000
            -428.5000 -613.5000
            -418.5000 -613.5000
            -408.5000 -613.5000
            -398.5000 -613.5000
            -388.5000 -613.5000
            -378.5000 -613.5000
            -368.5000 -613.5000
            -358.5000 -613.5000
            -348.5000 -613.5000
            -338.5000 -613.5000
            -328.5000 -613.5000
            -318.5000 -613.5000
            -308.5000 -613.5000
            -298.5000 -613.5000
            -288.5000 -613.5000
            -278.5000 -613.5000
            -268.5000 -613.5000
            -262.0000 -610.0000
            -263.0000 -601.0000
            -271.5000 -599.5000
            -280.5000 -598.5000
            -289.5000 -597.5000
            -297.5000 -595.5000
            -305.0000 -593.0000
            -311.5000 -589.5000
            -318.0000 -586.0000
            -323.0000 -581.0000
            -327.0000 -575.0000
            -330.5000 -568.5000
            -333.0000 -561.0000
            -333.0000 -551.0000
            -334.0000 -542.0000
            -334.0000 -532.0000
            -334.0000 -522.0000
            -334.0000 -512.0000
            -334.0000 -502.0000
            -334.0000 -492.0000
            -334.0000 -482.0000
            -334.0000 -472.0000
            -334.0000 -462.0000
            -334.0000 -452.0000
            -334.0000 -442.0000
            -334.0000 -432.0000
            -334.0000 -422.0000
            -334.0000 -412.0000
            -334.0000 -402.0000
            -334.0000 -392.0000
            -334.0000 -382.0000
            -334.0000 -372.0000
            -334.0000 -362.0000
            -334.0000 -352.0000
            -334.0000 -342.0000
            -334.0000 -332.0000
            -334.0000 -322.0000
            -334.0000 -312.0000
            -334.0000 -302.0000
            -334.0000 -292.0000
            -334.0000 -282.0000
            -334.0000 -272.0000
            -334.0000 -262.0000
            -334.0000 -252.0000
            -334.0000 -242.0000
            -334.0000 -232.0000
            -334.0000 -222.0000
            -334.0000 -212.0000
            -334.0000 -202.0000
            -334.0000 -192.0000
            -334.0000 -182.0000
            -332.0000 -174.0000
            -325.0000 -171.0000
            -317.5000 -168.5000
            -310.5000 -165.5000
            -303.5000 -162.5000
            -295.5000 -160.5000
            -288.5000 -157.5000
            -280.5000 -155.5000
            -272.5000 -153.5000
            -264.5000 -151.5000
            -256.5000 -149.5000
            -247.5000 -148.5000
            -239.5000 -146.5000
            -229.5000 -146.5000
            -220.5000 -145.5000
            -210.5000 -145.5000
            -201.5000 -146.5000
            -192.5000 -147.5000
            -185.0000 -150.0000
            -177.5000 -152.5000
            -171.5000 -156.5000
            -166.0000 -161.0000
            -161.0000 -166.0000
            -157.0000 -172.0000
            -153.0000 -178.0000
            -150.0000 -185.0000
            -148.0000 -193.0000
            -146.0000 -201.0000
            -145.0000 -210.0000
            -145.0000 -220.0000
            -144.0000 -229.0000
            -144.0000 -239.0000
            -144.0000 -249.0000
            -144.0000 -259.0000
            -144.0000 -269.0000
            -144.0000 -279.0000
            -144.0000 -289.0000
            -144.0000 -299.0000
            -144.0000 -309.0000
            -144.0000 -319.0000
            -144.0000 -329.0000
            -144.0000 -339.0000
            -144.0000 -349.0000
            -144.0000 -359.0000
            -144.0000 -369.0000
            -144.0000 -379.0000
            -144.0000 -389.0000
            -144.0000 -399.0000
            -144.0000 -409.0000
            -144.0000 -419.0000
            -144.0000 -429.0000
            -144.0000 -439.0000
            -144.0000 -449.0000
            -144.0000 -459.0000
            -144.0000 -469.0000
            -144.0000 -479.0000
            -144.0000 -489.0000
            -144.0000 -499.0000
            -144.0000 -509.0000
            -144.0000 -519.0000
            -144.0000 -529.0000
            -144.0000 -539.0000
            -144.0000 -549.0000
            -144.0000 -559.0000
            -144.0000 -569.0000
            -144.0000 -579.0000
            -144.0000 -589.0000
            -144.0000 -599.0000
            -144.0000 -609.0000
            -144.0000 -619.0000
            -144.0000 -629.0000
            -144.0000 -639.0000
            -144.0000 -649.0000
            -144.0000 -659.0000
            -144.0000 -669.0000
            -144.0000 -679.0000
            -144.0000 -689.0000
            -144.0000 -699.0000
            -145.0000 -708.0000
            -145.0000 -718.0000
            -147.0000 -726.0000
            -149.0000 -734.0000
            -152.5000 -740.5000
            -157.0000 -746.0000
            -163.0000 -750.0000
            -170.0000 -753.0000
            -177.5000 -755.5000
            -185.5000 -757.5000
            -194.5000 -758.5000
            -203.5000 -759.5000
            -213.5000 -759.5000
            -216.0000 -767.0000
            -212.5000 -773.5000
            -202.5000 -773.5000
            -192.5000 -773.5000
            -182.5000 -773.5000
            -172.5000 -773.5000
            -162.5000 -773.5000
            -152.5000 -773.5000
            -142.5000 -773.5000
            -132.5000 -773.5000
            -122.5000 -773.5000
            -112.5000 -773.5000
            -102.5000 -773.5000
            -92.5000 -773.5000
            -82.5000 -773.5000
            -72.5000 -773.5000
            -62.5000 -773.5000
            -52.5000 -773.5000
            -42.5000 -773.5000
            -32.5000 -773.5000
            -22.5000 -773.5000
            -12.5000 -773.5000
            -2.5000 -773.5000
            0 -766.0000
            -3.5000 -759.5000
            -13.0000 -759.0000
            -22.5000 -758.5000
            -30.5000 -756.5000
            -38.5000 -754.5000
            -45.5000 -751.5000
            -52.0000 -748.0000
            -58.0000 -744.0000
            -63.0000 -739.0000
            -67.0000 -733.0000
            -69.5000 -725.5000
            -71.0000 -717.0000
            -72.0000 -708.0000
            -72.0000 -698.0000
            -72.0000 -688.0000
            -72.0000 -678.0000
            -72.0000 -668.0000
            -72.0000 -658.0000
            -72.0000 -648.0000
            -72.0000 -638.0000
            -72.0000 -628.0000
            -72.0000 -618.0000
            -72.0000 -608.0000
            -72.0000 -598.0000
            -72.0000 -588.0000
            -72.0000 -578.0000
            -72.0000 -568.0000
            -72.0000 -558.0000
            -72.0000 -548.0000
            -72.0000 -538.0000
            -72.0000 -528.0000
            -72.0000 -518.0000
            -72.0000 -508.0000
            -72.0000 -498.0000
            -72.0000 -488.0000
            -72.0000 -478.0000
            -72.0000 -468.0000
            -72.0000 -458.0000
            -72.0000 -448.0000
            -72.0000 -438.0000
            -72.0000 -428.0000
            -72.0000 -418.0000
            -72.0000 -408.0000
            -72.0000 -398.0000
            -72.0000 -388.0000
            -72.0000 -378.0000
            -72.0000 -368.0000
            -72.0000 -358.0000
            -72.0000 -348.0000
            -72.0000 -338.0000
            -72.0000 -328.0000
            -72.0000 -318.0000
            -72.0000 -308.0000
            -72.0000 -298.0000
            -72.0000 -288.0000
            -72.0000 -278.0000
            -72.0000 -268.0000
            -72.0000 -258.0000
            -72.0000 -248.0000
            -72.0000 -238.0000
            -72.0000 -228.0000
            -73.0000 -219.0000
            -73.0000 -211.0000
            -73.0000 -201.0000
            -74.0000 -192.0000
            -74.5000 -182.5000
            -75.5000 -173.5000
            -77.0000 -165.0000
            -79.0000 -157.0000
            -82.5000 -150.5000
            -86.0000 -144.0000
            -90.5000 -138.5000
            -95.5000 -133.5000
            -101.0000 -129.0000
            -106.5000 -124.5000
            -113.0000 -121.0000
            -119.5000 -117.5000
            -126.5000 -114.5000
            -134.0000 -112.0000
            -141.5000 -109.5000
            -149.5000 -107.5000
            -158.5000 -106.5000
            -166.5000 -104.5000
            -176.5000 -104.5000
            -185.5000 -103.5000];

        vertices=[X; X(1,:)]/max(abs(X(:,1)));



    otherwise
        domain_str='NON CONVEX POLYGON';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];
end

vertices(end+1,:)=vertices(1,:);

vertices=vertices(:,1)+i*vertices(:,2);

domain_str=lower(domain_str);












function [Sx,Sy,vertices,domain_str]=gallery_curvpolygon(subexample)

% IMPORTANT:
% 1. First and last vertex, in each example, coincide.
% 2. vertices are a complex vector
% 3. Sx,Sy are splines that define parametrically the boundary as
%    (Sx(t),Sy(t))


P=[];

switch subexample

    case 1
        domain_str='UNIT SQUARE [0,1]^2';
        k=1;
        vertices=k*[0 0; 1 0; 1 1; 0 1];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

    case 2
        domain_str='CONVEX POLYGON';
        vertices=[0.1 0; 0.7 0.2; 1 0.5; 0.75 0.85; 0.5 1; 0 0.25];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

    case 3
        domain_str='NON CONVEX POLYGON';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 7; 2 size(vertices,1)];

    case 4
        domain_str='Polygon';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 4; 2 4; 0 3; 1 2];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[2 6; 4 size(vertices,1)];

    case 5
        domain_str='Polygon';
        vertices=(1/4)*[0 0; 1 2-0.1; 2 0; 3 2-0.1; 4 0; 4 4; 3 2; 2 4; ...
            1 2+0.1; 0 4];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[2 6; 3 10; 2 size(vertices,1)];


    case 6
        domain_str='UNIT SQUARE [-1,1]^2';
        vertices=[-1 -1; 1 -1; 1 1; -1 1];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

    case 7
        domain_str='UNIT TRIANGLE: [0 0; 1 0; 1 1]';
        vertices=[0 0; 1 0; 1 1];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

    case 8
        domain_str='PSEUDO-CIRCLE';
        N=40; a=0; b=2*pi;
        h=(b-a)/N; theta=(a:h:b-h)';
        x=cos(theta); y=sin(theta);
        x=0.5*x+0.5; y=0.5*y+0.5;
        vertices=[x y];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];


    case 9

        X=[
            -191.0000 -104.0000
            -200.5000 -104.5000
            -209.5000 -105.5000
            -218.5000 -106.5000
            -226.5000 -108.5000
            -235.0000 -110.0000
            -243.5000 -111.5000
            -251.5000 -113.5000
            -258.5000 -116.5000
            -266.5000 -118.5000
            -274.5000 -120.5000
            -281.5000 -123.5000
            -289.0000 -126.0000
            -296.5000 -128.5000
            -303.5000 -131.5000
            -310.5000 -134.5000
            -318.0000 -137.0000
            -325.0000 -140.0000
            -332.0000 -143.0000
            -334.0000 -136.0000
            -334.0000 -126.0000
            -334.0000 -116.0000
            -341.5000 -113.5000
            -351.5000 -113.5000
            -361.5000 -113.5000
            -371.5000 -113.5000
            -381.5000 -113.5000
            -391.5000 -113.5000
            -401.5000 -113.5000
            -411.5000 -113.5000
            -421.5000 -113.5000
            -431.5000 -113.5000
            -441.5000 -113.5000
            -451.5000 -113.5000
            -461.5000 -113.5000
            -471.5000 -113.5000
            -478.0000 -117.0000
            -477.0000 -126.0000
            -468.5000 -127.5000
            -459.5000 -128.5000
            -450.5000 -129.5000
            -441.5000 -130.5000
            -434.0000 -133.0000
            -427.0000 -136.0000
            -421.0000 -140.0000
            -416.0000 -145.0000
            -412.0000 -151.0000
            -409.0000 -158.0000
            -407.0000 -166.0000
            -407.0000 -176.0000
            -406.0000 -185.0000
            -406.0000 -195.0000
            -406.0000 -205.0000
            -406.0000 -215.0000
            -406.0000 -225.0000
            -406.0000 -235.0000
            -406.0000 -245.0000
            -406.0000 -255.0000
            -406.0000 -265.0000
            -406.0000 -275.0000
            -406.0000 -285.0000
            -406.0000 -295.0000
            -406.0000 -305.0000
            -406.0000 -315.0000
            -406.0000 -325.0000
            -406.0000 -335.0000
            -406.0000 -345.0000
            -406.0000 -355.0000
            -406.0000 -365.0000
            -406.0000 -375.0000
            -406.0000 -385.0000
            -406.0000 -395.0000
            -406.0000 -405.0000
            -406.0000 -415.0000
            -406.0000 -425.0000
            -406.0000 -435.0000
            -406.0000 -445.0000
            -406.0000 -455.0000
            -406.0000 -465.0000
            -406.0000 -475.0000
            -406.0000 -485.0000
            -406.0000 -495.0000
            -406.0000 -505.0000
            -406.0000 -515.0000
            -406.0000 -525.0000
            -406.0000 -535.0000
            -406.5000 -544.5000
            -407.0000 -554.0000
            -408.0000 -563.0000
            -410.0000 -571.0000
            -413.0000 -578.0000
            -417.5000 -583.5000
            -423.0000 -588.0000
            -429.5000 -591.5000
            -436.5000 -594.5000
            -444.5000 -596.5000
            -453.0000 -598.0000
            -462.5000 -598.5000
            -471.5000 -599.5000
            -478.0000 -603.0000
            -477.0000 -612.0000
            -468.5000 -613.5000
            -458.5000 -613.5000
            -448.5000 -613.5000
            -438.5000 -613.5000
            -428.5000 -613.5000
            -418.5000 -613.5000
            -408.5000 -613.5000
            -398.5000 -613.5000
            -388.5000 -613.5000
            -378.5000 -613.5000
            -368.5000 -613.5000
            -358.5000 -613.5000
            -348.5000 -613.5000
            -338.5000 -613.5000
            -328.5000 -613.5000
            -318.5000 -613.5000
            -308.5000 -613.5000
            -298.5000 -613.5000
            -288.5000 -613.5000
            -278.5000 -613.5000
            -268.5000 -613.5000
            -262.0000 -610.0000
            -263.0000 -601.0000
            -271.5000 -599.5000
            -280.5000 -598.5000
            -289.5000 -597.5000
            -297.5000 -595.5000
            -305.0000 -593.0000
            -311.5000 -589.5000
            -318.0000 -586.0000
            -323.0000 -581.0000
            -327.0000 -575.0000
            -330.5000 -568.5000
            -333.0000 -561.0000
            -333.0000 -551.0000
            -334.0000 -542.0000
            -334.0000 -532.0000
            -334.0000 -522.0000
            -334.0000 -512.0000
            -334.0000 -502.0000
            -334.0000 -492.0000
            -334.0000 -482.0000
            -334.0000 -472.0000
            -334.0000 -462.0000
            -334.0000 -452.0000
            -334.0000 -442.0000
            -334.0000 -432.0000
            -334.0000 -422.0000
            -334.0000 -412.0000
            -334.0000 -402.0000
            -334.0000 -392.0000
            -334.0000 -382.0000
            -334.0000 -372.0000
            -334.0000 -362.0000
            -334.0000 -352.0000
            -334.0000 -342.0000
            -334.0000 -332.0000
            -334.0000 -322.0000
            -334.0000 -312.0000
            -334.0000 -302.0000
            -334.0000 -292.0000
            -334.0000 -282.0000
            -334.0000 -272.0000
            -334.0000 -262.0000
            -334.0000 -252.0000
            -334.0000 -242.0000
            -334.0000 -232.0000
            -334.0000 -222.0000
            -334.0000 -212.0000
            -334.0000 -202.0000
            -334.0000 -192.0000
            -334.0000 -182.0000
            -332.0000 -174.0000
            -325.0000 -171.0000
            -317.5000 -168.5000
            -310.5000 -165.5000
            -303.5000 -162.5000
            -295.5000 -160.5000
            -288.5000 -157.5000
            -280.5000 -155.5000
            -272.5000 -153.5000
            -264.5000 -151.5000
            -256.5000 -149.5000
            -247.5000 -148.5000
            -239.5000 -146.5000
            -229.5000 -146.5000
            -220.5000 -145.5000
            -210.5000 -145.5000
            -201.5000 -146.5000
            -192.5000 -147.5000
            -185.0000 -150.0000
            -177.5000 -152.5000
            -171.5000 -156.5000
            -166.0000 -161.0000
            -161.0000 -166.0000
            -157.0000 -172.0000
            -153.0000 -178.0000
            -150.0000 -185.0000
            -148.0000 -193.0000
            -146.0000 -201.0000
            -145.0000 -210.0000
            -145.0000 -220.0000
            -144.0000 -229.0000
            -144.0000 -239.0000
            -144.0000 -249.0000
            -144.0000 -259.0000
            -144.0000 -269.0000
            -144.0000 -279.0000
            -144.0000 -289.0000
            -144.0000 -299.0000
            -144.0000 -309.0000
            -144.0000 -319.0000
            -144.0000 -329.0000
            -144.0000 -339.0000
            -144.0000 -349.0000
            -144.0000 -359.0000
            -144.0000 -369.0000
            -144.0000 -379.0000
            -144.0000 -389.0000
            -144.0000 -399.0000
            -144.0000 -409.0000
            -144.0000 -419.0000
            -144.0000 -429.0000
            -144.0000 -439.0000
            -144.0000 -449.0000
            -144.0000 -459.0000
            -144.0000 -469.0000
            -144.0000 -479.0000
            -144.0000 -489.0000
            -144.0000 -499.0000
            -144.0000 -509.0000
            -144.0000 -519.0000
            -144.0000 -529.0000
            -144.0000 -539.0000
            -144.0000 -549.0000
            -144.0000 -559.0000
            -144.0000 -569.0000
            -144.0000 -579.0000
            -144.0000 -589.0000
            -144.0000 -599.0000
            -144.0000 -609.0000
            -144.0000 -619.0000
            -144.0000 -629.0000
            -144.0000 -639.0000
            -144.0000 -649.0000
            -144.0000 -659.0000
            -144.0000 -669.0000
            -144.0000 -679.0000
            -144.0000 -689.0000
            -144.0000 -699.0000
            -145.0000 -708.0000
            -145.0000 -718.0000
            -147.0000 -726.0000
            -149.0000 -734.0000
            -152.5000 -740.5000
            -157.0000 -746.0000
            -163.0000 -750.0000
            -170.0000 -753.0000
            -177.5000 -755.5000
            -185.5000 -757.5000
            -194.5000 -758.5000
            -203.5000 -759.5000
            -213.5000 -759.5000
            -216.0000 -767.0000
            -212.5000 -773.5000
            -202.5000 -773.5000
            -192.5000 -773.5000
            -182.5000 -773.5000
            -172.5000 -773.5000
            -162.5000 -773.5000
            -152.5000 -773.5000
            -142.5000 -773.5000
            -132.5000 -773.5000
            -122.5000 -773.5000
            -112.5000 -773.5000
            -102.5000 -773.5000
            -92.5000 -773.5000
            -82.5000 -773.5000
            -72.5000 -773.5000
            -62.5000 -773.5000
            -52.5000 -773.5000
            -42.5000 -773.5000
            -32.5000 -773.5000
            -22.5000 -773.5000
            -12.5000 -773.5000
            -2.5000 -773.5000
            0 -766.0000
            -3.5000 -759.5000
            -13.0000 -759.0000
            -22.5000 -758.5000
            -30.5000 -756.5000
            -38.5000 -754.5000
            -45.5000 -751.5000
            -52.0000 -748.0000
            -58.0000 -744.0000
            -63.0000 -739.0000
            -67.0000 -733.0000
            -69.5000 -725.5000
            -71.0000 -717.0000
            -72.0000 -708.0000
            -72.0000 -698.0000
            -72.0000 -688.0000
            -72.0000 -678.0000
            -72.0000 -668.0000
            -72.0000 -658.0000
            -72.0000 -648.0000
            -72.0000 -638.0000
            -72.0000 -628.0000
            -72.0000 -618.0000
            -72.0000 -608.0000
            -72.0000 -598.0000
            -72.0000 -588.0000
            -72.0000 -578.0000
            -72.0000 -568.0000
            -72.0000 -558.0000
            -72.0000 -548.0000
            -72.0000 -538.0000
            -72.0000 -528.0000
            -72.0000 -518.0000
            -72.0000 -508.0000
            -72.0000 -498.0000
            -72.0000 -488.0000
            -72.0000 -478.0000
            -72.0000 -468.0000
            -72.0000 -458.0000
            -72.0000 -448.0000
            -72.0000 -438.0000
            -72.0000 -428.0000
            -72.0000 -418.0000
            -72.0000 -408.0000
            -72.0000 -398.0000
            -72.0000 -388.0000
            -72.0000 -378.0000
            -72.0000 -368.0000
            -72.0000 -358.0000
            -72.0000 -348.0000
            -72.0000 -338.0000
            -72.0000 -328.0000
            -72.0000 -318.0000
            -72.0000 -308.0000
            -72.0000 -298.0000
            -72.0000 -288.0000
            -72.0000 -278.0000
            -72.0000 -268.0000
            -72.0000 -258.0000
            -72.0000 -248.0000
            -72.0000 -238.0000
            -72.0000 -228.0000
            -73.0000 -219.0000
            -73.0000 -211.0000
            -73.0000 -201.0000
            -74.0000 -192.0000
            -74.5000 -182.5000
            -75.5000 -173.5000
            -77.0000 -165.0000
            -79.0000 -157.0000
            -82.5000 -150.5000
            -86.0000 -144.0000
            -90.5000 -138.5000
            -95.5000 -133.5000
            -101.0000 -129.0000
            -106.5000 -124.5000
            -113.0000 -121.0000
            -119.5000 -117.5000
            -126.5000 -114.5000
            -134.0000 -112.0000
            -141.5000 -109.5000
            -149.5000 -107.5000
            -158.5000 -106.5000
            -166.5000 -104.5000
            -176.5000 -104.5000
            -185.5000 -103.5000];

        vertices=[X; X(1,:)]/max(abs(X(:,1)));
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

    case 11
        domain_str='WINGS';
        X0=0.3*[0 1 2 3 4];
        X=[X0 3.5 2 -1];
        Y=[0 2 4.5 2 0 3.5 5 3.5];
        vertices=[X' Y'];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];



    otherwise
        domain_str='NON CONVEX POLYGON';
        vertices=(1/4)*[1 0; 3 2; 3 0; 4 2; 3 3; 3 0.85*4; 2 4; ...
            0 3; 1 2];
        vertices(end+1,:)=vertices(1,:);

        spline_type='not-a-knot';
        spline_parms=[4 size(vertices,1)];

end

X=vertices(:,1); Y=vertices(:,2); % sampling points in each variable


% Determine the spline boundary via the vectors of splines "Sx" and "Sy".
[Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);
vertices=X+i*Y;
domain_str=lower(domain_str);



function [Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type)

%..........................................................................
% OBJECT:
%
% This subroutine, starting from the sampling values of the boundary in X
% and Y (i.e. sampling points are the rows of the matrix [X Y]) it computes
% the parametrical description of the boundary in the "x" and "y" variable,
% via many spline, with possible different order, as described in
% "spline_parms".
%
% INPUT:
%
% X,Y: sampling points (X,Y) described as column vectors.
%
% spline_parms: spline order and block (vector).
%
%            [spline_parms(i,1)=2] : piecewise linear splines.
%            [spline_parms(i,1)=4] : cubic splines
%                         (depending on "spltypestring" in input).
%            [spline_parms(i,1)=k] : in the case k is not 2 or 4 it
%                          chooses the k-th order splines (for additional
%                          help digit "help spapi" in matlab shell).
%
%            [spline_parms(:,2)]: vector of final components of a block.
%
%            example:
%
%            "spline_parms=[2 31; 4 47; 8 67]" means that from the 1st
%             vertex to the 31th vertex we have an order 2 spline (piecewise
%             linear), from the 32th vertex to the 47th we use a 4th order
%             spline (i.e. a cubic and periodic spline by default), from
%             the 48th to the 67th (and final!) we use an 8th order spline.
%
% spline_type: in case of cubic spline, it describes the type of spline
%      by string. It is used by Matlab built-in routine "csape". Available
%      choices are found at
%
%             https://www.mathworks.com/help/curvefit/csape.html
%
%      and can be
%
%        'complete'   : match endslopes (as given in VALCONDS, with
%                     default as under *default*).
%       'not-a-knot' : make spline C^3 across first and last interior
%                     break (ignoring VALCONDS if given).
%       'periodic'   : match first and second derivatives at first
%                     data point with those at last data point (ignoring
%                     VALCONDS if given).
%       'second'     : match end second derivatives (as given in
%                    VALCONDS, with default [0 0], i.e., as in variational).
%       'variational': set end second derivatives equal to zero
%                     (ignoring VALCONDS if given).
%
% OUTPUT:
%
% Sx: vector whose k-th component is a spline describing the k-th spline
%     component describing the boundary, i.e. for certain [t(k),t(k+1] we
%     have that "x(t)=s(t)" with "s=Sx(k)".
%
% Sy: vector whose k-th component is a spline describing the k-th spline
%     component describing the boundary in the variable "y", i.e. for
%     certain [t(k),t(k+1] we have that "y(t)=s(t)" with "s=Sy(k)".
%
% Important note: Sx and Sy have the same "breaks" in each component, this
% meaning that "(Sx(k)).breaks=(Sy(k)).breaks".
%..........................................................................


% ................ troubleshooting ................

% Detting default as periodic cubic spline in case "spline_parms" is not
% declared.

if nargin < 3
    spline_parms=[4 length(X)];
end

if size(spline_parms,1) == 0
    spline_parms=[4 length(X)];
end

if nargin < 4
    spline_type='periodic';
end

% ................ splines definition ................

L=size(spline_parms,1);

for i=1:L % define spline

    % first and last index to consider
    if i == 1
        imin=1;
    else
        imin=spline_parms(i-1,2);
    end

    imax=spline_parms(i,2);

    tL=imin:imax; xL=X(imin:imax); yL=Y(imin:imax);

    [SxL,SyL]=compute_parametric_spline(tL,xL,yL,spline_parms(i,1),...
        spline_type);

    Sx(i)=SxL; Sy(i)=SyL;

end









%--------------------------------------------------------------------------
% compute_parametric_spline
%--------------------------------------------------------------------------

function [ppx,ppy]=compute_parametric_spline(s,x,y,spline_order,...
    spline_type)

%..........................................................................
% Object:
%
% Compute parametric spline relavant parameters "ppx", "ppy" so that a
% point at the boundary of the  domain has coordinates (x(s),y(s))
%
% Input:
% s: parameter data.
% x: determine spline x(s) interpolating (s,x)
% y: determine spline y(s) interpolating (s,y)
% spline_order: spline order (i.e. degree + 1)
% spline_type: string with the spline type i.e.
%             'complete'   : match endslopes (as given in VALCONDS, with
%                     default as under *default*).
%             'not-a-knot' : make spline C^3 across first and last interior
%                     break (ignoring VALCONDS if given).
%             'periodic'   : match first and second derivatives at first
%                     data point with those at last data point (ignoring
%                     VALCONDS if given).
%             'second'     : match end second derivatives (as given in
%                    VALCONDS, with default [0 0], i.e., as in variational).
%             'variational': set end second derivatives equal to zero
%                     (ignoring VALCONDS if given).
%     If "spline_type" is not declared or equal to "[]", we use 'periodic'.
%
% Output:
% ppx: spline x(t) data
% ppy: spline y(t) data
%..........................................................................

% ................ troubleshooting ................

% Detting default as periodic cubic spline in case "spline_parms" is not
% declared.
if nargin < 5
    spline_type = 'periodic';
end

if strlength(spline_type) == 0
    spline_type = 'periodic';
end


% ................ splines definition ................

% fprintf('\n \t order %3.0f: ',spline_order);
% tic;
switch spline_order
    case 4

        % Cubic splines: using "csape".
        ppx=csape(s,x,spline_type); ppy=csape(s,y,spline_type);

    otherwise

        % Non cubic splines: using "spapi".
        ppx=spapi(spline_order,s,x); ppy=spapi(spline_order,s,y);

end
% toc;

%..........................................................................
% Note:
%..........................................................................
% The routine "spapi" gives splines in "B-"form while "csape" in "pp"form.
% We brutally normalise them so to be in "pp" form, to simplify further
% code.
%
% The two forms are not equal, but provide "close" function (relative error
%  close to machine precision).
%
% This normalisation is requested to save all splines components as vector.
%..........................................................................

% fprintf('\n \t Changing form: ');
% tic;
if (ppx.form =='B-')
    ppx=fn2fm(ppx,'pp'); ppy=fn2fm(ppy,'pp');
end
% toc;









function [cents,rs]=gallery_uniondisks(example)

% COMPLEX DOMAIN AS UNION OF DISKS.
% IMPORTANT: cents elements are complex numbers.

if nargin < 1
    example=0;
end

switch example

    case 0
        disks=[ 4.172670690843695e-01 6.443181301936917e-01 3.630885392869130e-01
            4.965443032574213e-02 3.786093826602684e-01 5.468057187389680e-01
            9.027161099152811e-01 8.115804582824772e-01 5.211358308040015e-01
            9.447871897216460e-01 5.328255887994549e-01 2.315943867085238e-01
            5.085086553811270e-01 4.886089738035791e-01 3.786806496411588e-01
            5.107715641721097e-01 5.785250610234389e-01 7.126944716789141e-01
            8.176277083222621e-01 2.372835797715215e-01 5.004716241548430e-01
            7.948314168834530e-01 4.588488281799311e-01 4.710883745419393e-01
            ];

        cents=disks(:,1:2);
        rs=disks(:,3);
    case 1
        disks=[5.085086553811270e-01 4.886089738035791e-01 9.786806496411588e-01
            5.107715641721097e-01 5.785250610234389e-01 7.126944716789141e-01
            8.176277083222621e-01 2.372835797715215e-01 5.004716241548430e-01
            7.948314168834530e-01 4.588488281799311e-01 4.710883745419393e-01
            4.172670690843695e-01 6.443181301936917e-01 9.630885392869130e-01
            4.965443032574213e-02 3.786093826602684e-01 5.468057187389680e-01
            9.027161099152811e-01 8.115804582824772e-01 5.211358308040015e-01
            9.447871897216460e-01 5.328255887994549e-01 2.315943867085238e-01
            4.908640924680799e-01 3.507271035768833e-01 4.888977439201669e-01
            4.892526384000189e-01 9.390015619998868e-01 6.240600881736895e-01
            3.377194098213772e-01 8.759428114929838e-01 6.791355408657477e-01
            9.000538464176620e-01 5.501563428984222e-01 3.955152156685930e-01
            3.692467811202150e-01 6.224750860012275e-01 3.674366485444766e-01
            1.112027552937874e-01 5.870447045314168e-01 9.879820031616328e-01
            7.802520683211379e-01 2.077422927330285e-01 3.773886623955214e-02
            3.897388369612534e-01 3.012463302794907e-01 8.851680082024753e-01
            2.416912859138327e-01 4.709233485175907e-01 9.132868276392390e-01
            4.039121455881147e-01 2.304881602115585e-01 7.961838735852120e-01
            9.645452516838859e-02 8.443087926953891e-01 9.871227865557430e-02
            1.319732926063351e-01 1.947642895670493e-01 2.618711838707161e-01
            9.420505907754851e-01 2.259217809723988e-01 3.353568399627965e-01
            9.561345402298023e-01 1.707080471478586e-01 6.797279513773380e-01
            5.752085950784656e-01 2.276642978165535e-01 1.365531373553697e-01
            5.977954294715582e-02 4.356986841038991e-01 7.212274985817402e-01
            2.347799133724063e-01 3.111022866504128e-01 1.067618616072414e-01
            3.531585712220711e-01 9.233796421032439e-01 6.537573486685596e-01
            8.211940401979591e-01 4.302073913295840e-01 4.941739366392701e-01
            1.540343765155505e-02 1.848163201241361e-01 7.790517232312751e-01
            4.302380165780784e-02 9.048809686798929e-01 7.150370784006941e-01
            1.689900294627044e-01 9.797483783560852e-01 9.037205605563163e-01
            6.491154749564521e-01 4.388699731261032e-01 8.909225043307892e-01
            7.317223856586703e-01 1.111192234405988e-01 3.341630527374962e-01
            6.477459631363067e-01 2.580646959120669e-01 6.987458323347945e-01
            4.509237064309449e-01 4.087198461125521e-01 1.978098266859292e-01
            5.470088922863450e-01 5.948960740086143e-01 3.054094630463666e-02
            2.963208056077732e-01 2.622117477808454e-01 7.440742603674624e-01
            7.446928070741562e-01 6.028430893820830e-01 5.000224355902009e-01
            1.889550150325445e-01 7.112157804336829e-01 4.799221411460605e-01
            6.867754333653150e-01 2.217467340172401e-01 9.047222380673627e-01
            1.835111557372697e-01 1.174176508558059e-01 6.098666484225584e-01
            3.684845964903365e-01 2.966758732183269e-01 6.176663895884547e-01
            6.256185607296904e-01 3.187783019258823e-01 8.594423056462123e-01
            7.802274351513768e-01 4.241667597138072e-01 8.054894245296856e-01
            8.112576886578526e-02 5.078582846611182e-01 5.767215156146851e-01
            9.293859709687300e-01 8.551579709004398e-02 1.829224694149140e-01
            7.757126786084023e-01 2.624822346983327e-01 2.399320105687174e-01
            4.867916324031724e-01 8.010146227697388e-01 8.865119330761013e-01
            4.358585885809191e-01 2.922027756214629e-02 2.867415246410610e-02
            4.467837494298063e-01 9.288541394780446e-01 4.899013885122239e-01
            3.063494720165574e-01 7.303308628554529e-01 1.679271456822568e-01
            5.085086553811270e-01 4.886089738035791e-01 9.786806496411588e-01
            5.107715641721097e-01 5.785250610234389e-01 7.126944716789141e-01
            8.176277083222621e-01 2.372835797715215e-01 5.004716241548430e-01
            7.948314168834530e-01 4.588488281799311e-01 4.710883745419393e-01
            ];

        Ndisks=15;
        cents=disks(1:Ndisks,1:2);
        rs=disks(1:Ndisks,3);

    case 2

        M=20;
        angles=linspace(0,2*pi,M);
        angles=angles';

        r1=2;
        cents1=r1*[cos(angles) sin(angles)];
        rs1=(r1/4)*ones(size(cents1,1),1);

        r2=4;
        cents2=r2*[cos(angles) sin(angles)];
        rs2=(r2/4)*ones(size(cents2,1),1);

        cents=[cents1; cents2];
        rs=[rs1; rs2];

    case 3

        M=45;

        t=linspace(0,5,M);
        y=2*t;
        x=2.5*cos(2*t);
        cents=[x' y'];
        x=2.5*sin(2*t);
        cents0=[x' y'];
        cents=[cents; cents0];
        rs=0.3*ones(size(cents,1),1);

    case 4

        cents=[0 0];
        rs=1;

    otherwise
        M=100;
        cents=rand(M,2);
        rs=rand(M,1);
end

cents=cents(:,1)+i*cents(:,2);

