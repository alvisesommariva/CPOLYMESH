
function [zAM,C]=complex_AM(domain,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a complex domain.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: domain structure (dependent on the domain, see "define_domain.m");
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% EXAMPLE OF DOMAINS (see "define_domain"):
%--------------------------------------------------------------------------
%
%     example 1: 'sun';
%     example 2: 'polygon';
%     example 3: 'cardioid';
%     example 4: 'curvpolygon';
%     example 5: 'uniondisks';
%     example 6: 'lune';
%     example 7: 'hypocycloid';
%     example 8: 'epicycloid';
%     example 9: 'epitrochoid';
%     example 10: 'limacon';
%     example 11: 'ellipse';
%     example 12: 'deltoid';
%     example 13: 'deltoid';
%     example 14: 'rhodonea';
%     example 15: 'habenicht_clover';
%     example 16: 'egg'
%     example 17: 'bifolium'
%     example 18: 'torpedo'
%
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 24, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

zAM=[]; C=[];
switch domain.name
    case 'sun'
        [zAM,C]=complex_sun_AM(domain,deg,m);
    case 'polygon'
        [zAM,C]=complex_polygon_AM(domain.vertices,deg,m);
    case 'cardioid'
        [zAM,C]=complex_cardioid_AM(deg,m);
    case 'curvpolygon'
        [zAM,C]=complex_curvpolygon_AM(domain.Sx,domain.Sy,deg,m);
    case 'uniondisks'
        [zAM,C]=complex_diskunion_AM(domain.centers,domain.rs,deg,m);
    case 'lune'
        [zAM,C]=complex_lune_AM(domain.centers,domain.rs,deg,m);
    case 'hypocycloid'
         [zAM,C]=complex_hypocycloid_AM(domain.a,domain.b,deg,m);
    case 'epicycloid'
         [zAM,C]=complex_epicycloid_AM(domain.r,domain.R,deg,m);
     case 'epitrochoid'
         [zAM,C]=complex_epitrochoid_AM(domain.r,domain.R,domain.d,deg,m);
   case 'limacon'
         [zAM,C]=complex_limacon_AM(domain.a,domain.b,deg,m);
    case 'ellipse'
         [zAM,C]=complex_ellipse_AM(domain.a,domain.b,deg,m);    
    case 'lissajous'
         [zAM,C]=complex_lissajous_AM(domain.aV,domain.wV,domain.phiV,...
             deg,m); 
    case 'deltoid'
         [zAM,C]=complex_deltoid_AM(deg,m);
    case 'rhodonea'
         [zAM,C]=complex_rhodonea_AM(domain.a,domain.k,deg,m); 
    case 'habenicht_clover'
        [zAM,C]=complex_habenicht_clover_AM(domain.n,deg,m);
    case 'egg'
        [zAM,C]=complex_egg_AM(domain.a,domain.n,deg,m);
    case 'bifolium'
        [zAM,C]=complex_bifolium_AM(deg,m);
    case 'torpedo'
        [zAM,C]=complex_torpedo_AM(domain.a,deg,m);
    otherwise
        error('domain not included in list');
end








% .............................. SUN ......................................

function [zAM,C]=complex_sun_AM(domain,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg".
%
% Domain: complex sun.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: centers as complex numbers and radii (column vectors!).
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 11, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

% Domain

center=domain.center; r=domain.radius;
beams=domain.beams; beamslength=domain.beamslength;

% AM on the disk
[zAM1,C1]=complex_arc_AM(center,r,[0 2*pi],deg,m);

% SECOND ARC
zAM2=[]; C2=[];
theta=linspace(0,2*pi,beams+1);
theta=theta(1:end-1);
for k=1:beams
    thetaL=theta(k);
    vertices(1)=center+r*exp(i*thetaL);
    vertices(2)=center+(r+beamslength)*exp(i*thetaL);
    [zAM2L,C2L]=complex_segment_AM(vertices,deg,m);
    zAM2=[zAM2; zAM2L];
    C2=[C2; C2L];
end

zAM=[zAM1; zAM2];
C2max=max(C2);
C=max([C1 C2max]);







% .............................. SEGMENT ..................................

function [zAM,C]=complex_segment_AM(vertices,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*mu".
% 
% Domain: complex segment.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% vertices: vector, with two components, of complex vertices;
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

if nargin < 3, m=4; end

% Building reference AM on segment.

mAM=m*deg;

k=1:mAM; ptsAMR=cos((2*k-1)*pi/(2*mAM)); % reference points on segment
thetaAM=0.5*(ptsAMR'+1);

% Building complex-segment AM
X=real(vertices); Y=imag(vertices); X=X(:); Y=Y(:);
XL1=X(1); YL1=Y(1); XL2=X(2); YL2=Y(2);
XL=(1-thetaAM)*XL1+thetaAM*XL2; YL=(1-thetaAM)*YL1+thetaAM*YL2;
ptsAM=[XL YL];
zAM=ptsAM(:,1)+i*ptsAM(:,2);

% AM constant in norming set inequality.
C=1/cos(pi/(2*mAM)); % Real Chebyshev constant on the segment.








% .............................. ARC ......................................

function [zAM,C]=complex_arc_AM(center,r,theta,deg,m)

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% ADMISSIBLE MESH OVER AN ARC OF A COMPLEX DISK.
%--------------------------------------------------------------------------
% Input:
%--------------------------------------------------------------------------
% center: disk center (complex number);
% r: disk radius;
% theta: angles of the arc (choose theta(1) < theta(2), even if not in
%      [0,2*pi]);
% deg: AM degree;
% m: AM factor.
%--------------------------------------------------------------------------
% Output:
%--------------------------------------------------------------------------
% zAM: Admissible mesh points;
% C  : Norming set factor.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

if nargin < 4, m=2; end

% Building reference AM on sides.

N=2*m*deg; % card AM
j=1:N; xC=cos((2*j-1)*pi/(2*N)); % cheb. reference points on [-1,1]

a=theta(1); b=theta(2);

sigma_u=2*asin(xC'*sin((b-a)/4));
angs=(b+a)/2+sigma_u;

zAM=center+r*(cos(angs)+i*sin(angs));

% AM constant in norming set inequality.
C=1/cos(pi/(2*m));









% ........................... CURV POLYGON ................................

function [zAM,C]=complex_curvpolygon_AM(Sx,Sy,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a complex curvilinear
% polygon.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% Sx,Sy: parametric spline representation as Sx(t)+i*Sy(t).
% deg: AM degree
% m: AM factor (deg*m+1 points for each side)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% zAM: Admissible mesh points
% C  : Norming set factor.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

if nargin < 2, m=2; end

% ....................... AM over parametric splines ......................

L=length(Sx);
C=[]; % AM constant
zAM=[]; % AM over spline curvilinear domain

for ii=1:L

    SxL=Sx(ii);
    SyL=Sy(ii);

    SxL_breaks=SxL.breaks;

    Nbreaks=length(SxL_breaks);

    for kk=1:Nbreaks-1

        t0=SxL_breaks(kk); t1=SxL_breaks(kk+1);

        % reference points on segment
        deg_poly=max([SxL.order SxL.order])-1;
        mAM=ceil(m*deg*deg_poly);
        k=1:mAM; ptsR=0.5*(1+cos((2*k-1)*pi/(2*mAM)));

        % build AM over arc
        tt=t0+(t1-t0)*ptsR';
        xx=ppval(SxL,tt); yy=ppval(SyL,tt);
        zz=xx+i*yy;
        zAM=[zAM; zz];

        % AM constant arc.
        C(end+1)=1/cos(deg*pi/(2*mAM));

    end

end

C=max(C);









% ............................. DELTOID ...................................

function [zAM,C]=complex_deltoid_AM(deg,mu)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree.
%
% Domain: complex deltoid.
% Equation: z(t)=2*cos(t)+cos(2*t)+i*( 2*sin(t)-sin(2*t) );
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree
% mu: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

if nargin < 2, mu=2; end

% Building reference AM on sides.
N=ceil(2*mu*deg); % card AM
N=2*N; % This factor is due to the fact that the deltoid is parametrically
% described by trigonometric polynomials of degree 2.

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

omega=pi;

thR=2*asin(xC'*sin(omega/2));
th=thR+omega;

zAMR=2*cos(th)+cos(2*th);
zAMI=2*sin(th)-sin(2*th);
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*mu)); % Trigonometric constant.









% ............................ UNION DISKS ................................

function [zAM,C]=complex_diskunion_AM(centers,rs,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg).
%
% Domain: union of complex disks.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% centers, rs: vectors M x 1 in which each row is respectively a center as
%              complex number and a disk radii;
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

zAM=[]; C=[];
for k=1:length(rs)
    [zAML,CL]=complex_arc_AM(centers(k),rs(k),[0,2*pi],deg,m);
    zAM=[zAM; zAML]; C=[C; CL];
end

% Union of the pointsets and AM constant
C=max(C);









% ............................ POLYGONS ...................................

function [zAM,C]=complex_polygon_AM(vertices,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a complex curvilinear
% polygon.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% vertices: complex vector of vertices (first and last vertex are equal);
% deg: AM degree;
% m: AM factor.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% zAM: Admissible mesh points
% C  : Norming set factor.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 18, 2023 (Alvise Sommariva)
% Modified on October 18, 2023 (Alvise Sommariva)
% Authors: Alvise Sommariva
%--------------------------------------------------------------------------

if nargin < 3, m=8; end

% 1. Building reference AM on sides.
N=m*deg;
k=1:N;
ptsAMR=cos((2*k-1)*pi/(2*N)); % reference points on segment
thetaAM=0.5*(ptsAMR'+1);

% 2. Building complex-polygon AM

Nsides=length(vertices)-1;

X=real(vertices); Y=imag(vertices);
zAM=[];
for k=1:Nsides
    XL1=X(k); YL1=Y(k); XL2=X(k+1); YL2=Y(k+1);
    XL=(1-thetaAM)*XL1+thetaAM*XL2;
    YL=(1-thetaAM)*YL1+thetaAM*YL2;
    zAML=XL+i*YL;
    zAM=[zAM; zAML];
end

% 3. AM constant in norming set inequality.
C=1/cos(deg*pi/(2*N)); % Real Chebyshev constant in interval [-1,1].









% ............................ CARDIOID ...................................

function [zAM,C]=complex_cardioid_AM(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex cardioid.
% Equation: z(t)=cos(t).*(1-cos(t))+i*(sin(t).*(1-cos(t)))
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 12, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 2, m=8; end

% Building reference AM on sides.
N=2*m*deg; % card AM
N=2*N; % This factor is due to the fact that the cardioid is parametrically
% described by trigonometric polynomials of degree 2.

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

a=-pi; b=pi;

thR=2*asin(xC'*sin((b-a)/4))+(b+a)/2;
th=pi+thR;

% Mapping the AM to a cardioid "th" in [0,2*pi]
zAMR=cos(th).*(1-cos(th));
zAMI=sin(th).*(1-cos(th));
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ LUNE ...................................

function [zAM,C]=complex_lune_AM(centers,R,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*mu".
% 
% Domain: complex lune.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% centers, rs: centers as complex numbers and radii (column vectors!).
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 11, 2023.
% Author: Alvise Sommariva
%--------------------------------------------------------------------------

% Note: working in R^2 geometry and pull itt back to C.

C=[real(centers) imag(centers)];
[Xi,Yi]=intersection_pts(C,R);

% FIRST ARC
C1=C(1,:);
[angs1(1),r1(1)]=compute_angles(C1,[Xi(1) Yi(1)]);
[angs1(2),r1(2)]=compute_angles(C1,[Xi(2) Yi(2)]);

index=decide_arc(C1,R(1),angs1);

P1=[Xi(index(1)) Yi(index(1))];
P2=[Xi(index(2)) Yi(index(2))];

angs1=angs1(index);
if angs1(2) < angs1(1), angs1(2)=angs1(2)+2*pi; end
C1C=C1(1)+i*C1(2);

[zAM1,C1]=complex_arc_AM(C1C,R(1),angs1,deg,m);

% SECOND ARC
C2=C(2,:);
[angs2(1),r2(1)]=compute_angles(C2,[P1(1) P1(2)]);
[angs2(2),r2(2)]=compute_angles(C2,[P2(1) P2(2)]);
if angs2(2) < angs2(1), angs2(2)=angs2(2)+2*pi; end
C2C=C2(1)+i*C2(2);

[zAM2,C2]=complex_arc_AM(C2C,R(2),angs2,deg,m);

zAM=[zAM1; zAM2];
C=max([C1 C2]);



function [xout,yout]=intersection_pts(cents,rs)

x1=cents(1,1); y1=cents(1,2); r1=rs(1);
x2=cents(2,1); y2=cents(2,2); r2=rs(1);

C1=[x1 y1]; C2=[x2 y2]; dist_C1_C2=norm(C1-C2);
tol=10^(-13);
if abs(dist_C1_C2-(r1+r2)) <= tol
    % warning('Possibly tangent disks (type 1 test).');
    xout =[NaN   NaN]; yout =[NaN   NaN];
else
    % determine intersection
    [xout,yout] = circcirc(x1,y1,r1,x2,y2,r2);

    % after tests we have noticed that dig=13 may not be enough.
    dig=12;
    spts0=[xout' yout'];
    [spts,ind] = uniquepts(spts0,dig);
    xout=xout(ind); yout=yout(ind);

    if norm(size(spts0)-size(spts)) > 0
        %warning('Possibly tangent disks (type 2 test).');
        xout =[NaN   NaN]; yout =[NaN   NaN];
    end
end



function [spts,ind] = uniquepts(pts,dig)
 
%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% eliminates from an array of points pts those having dig digits
% in common with a subset of other points, keeping only one per subset
%--------------------------------------------------------------------------

atol=100*eps;   
m=10.^(floor(log10(abs(pts))-dig+1));
pts1=round(pts./m).*m;
pts1(find(abs(pts)<atol)) = 0;
[spts,ind]=unique(pts1,'rows');



function [angle_pt,radius_pt]=compute_angles(centers,point)

% input:
%
% centers are given by rows: centers=[X Y] with X,Y column vectors.
% point is a row vector.

% angle_pt is in [0,2*pi].

% VECTOR ROUTINE.

% N=size(centers,1);
%
% point_rep=repmat(point,N,1);
%
% ref_point=point_rep-centers;
% X=ref_point(:,1);
% Y=ref_point(:,2);
% [angle_pt,radius_pt] = cart2pol(X,Y);
% angle_pt=rem(angle_pt+2*pi,2*pi);

N=size(centers,1);
ref_point=point-centers;
X=ref_point(:,1);
Y=ref_point(:,2);
[angle_pt,radius_pt] = cart2pol(X,Y);
angle_pt=rem(angle_pt+2*pi,2*pi);




function index=decide_arc(center,r,angs)

CX=center(1); CY=center(2);
theta1=angs(1); theta2=angs(2);
P1=[CX+r*cos(theta1) CY+r*sin(theta1) 0];
P2=[CX+r*cos(theta2) CY+r*sin(theta2) 0];

A=P2-P1;

B=[CX CY 0]-P1;

C=cross(A,B);
if C(3) > 0
    index=[2 1];
else
    index=[1 2];
end









% ............................ HYPOCYCLOID ...................................

 function [zAM,C]=complex_hypocycloid_AM(a,b,deg,m)
 
 
%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex hypocycloid.
% Equation: 
% z(t)=((a-b)*cos(t)+b*cos((a-b)*t/b)+i*((a-b)*sin(t)-b*sin((a-b)*t/b));
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,b: parameters defining the hypocycloid, with a/b natural number.
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

if ceil(a/b) > a/b, 
    error('In defining the domain a must be a multiple of b'); 
end

if a < b, error('In defining the domain, choose a >= b'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=max(1,(a-b)/b);
N=dom_deg*N; 

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAMR=(a-b)*cos(th)+b*cos((a-b)*th/b);
zAMI=(a-b)*sin(th)-b*sin((a-b)*th/b);
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ EPYCYCLOID ...................................

 function [zAM,C]=complex_epicycloid_AM(r,R,deg,m)
 
 %--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex epicycloid.
% Equation:
% z(t)=(R+r)*cos(t)-r*cos((R+r)*t/r)+i*((R+r)*sin(t)-r*sin((R+r)*t/r))
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% r,R: parameters defining the hypocycloid, with r < R,
%       R multiple of r.
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

if ceil(R/r) > R/r
    error('In defining the domain R must be a multiple of r'); 
end
if R < r, error('In defining the domain, choose R >= r'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=max(1,(R+r)/r);
N=dom_deg*N; 

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAMR=(R+r)*cos(th)-r*cos((R+r)*th/r);
zAMI=(R+r)*sin(th)-r*sin((R+r)*th/r);
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ EPITROCHOID ...................................

function  [zAM,C]=complex_epitrochoid_AM(r,R,d,deg,m)
 
 %--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex epitrochoid.
% Equation:
% z(t)=(R+r)*cos(t)-d*cos((R+r)*t/r)+i*((R+r)*sin(t)-d*sin((R+r)*t/r))
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% r,R: parameters defining the hypocycloid, with r < R, 
%      R multiple of r.
% deg: interpolation degree
% m: AM factor
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 5, m=8; end

if ceil(R/r) > R/r, 
    error('In defining the domain R must be a multiple of r'); 
end
if R < r, error('In defining the domain, choose R >= r'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=max(1,(R+r)/r);
N=dom_deg*N; 

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAMR=(R+r)*cos(th)-d*cos((R+r)*th/r);
zAMI=(R+r)*sin(th)-d*sin((R+r)*th/r);
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ EPITROCHOID ...................................

function  [zAM,C]=complex_limacon_AM(a,b,deg,m)
 
 %--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex limacon.
% Equation: z(t)=(b/2)+a*exp(i*t)+(b/2)*exp(2*i*t);
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,b: parameters defining the domain; for avoiding auto-intersections 
%      choose "b <= a"; the domain is convex if "a >= 2*b", concave if
%      "b <= a < 2*b";
%      the limacon is defined as 
%              z(t)=(b/2)+a*exp(i*t)+(b/2)*exp(2*i*t);
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=2;
N=dom_deg*N;

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAM=(b/2)+a*exp(i*th)+(b/2)*exp(2*i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ ELLIPSE ....................................

function  [zAM,C]=complex_ellipse_AM(a,b,deg,m)
 
%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex ellipse.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,b: parameters defining the domain (length semiaxis); 
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=1;
N=dom_deg*N;

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAMR=a*cos(th);
zAMI=b*sin(th);
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ LISSAJOUS ..................................

function  [zAM,C]=complex_lissajous_AM(aV,wV,phiV,deg,m)
 
%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by Lissajous curves (e.g.
% w(1)=1, w(2)=2, other choices may not be reasonable).
% Equation:
% z(t)=a1*sin(w1*t+phi1)+i*(aV(2)*sin(w2*t+phi2)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% aV,wV,phiV: parameters defining the domain, i.e. z(t)=x(t)+i*y(t) with
%         x(t)=aV(1)*sin(wV(1)+phiV(1)), 
%         y(t)=aV(2)*sin(wV(2)+phiV(2)) 
%      with wV vector of positive integers.
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 5, m=8; end

if norm(ceil(wV)-wV) > 0, error('w''s must be positive integers'); end
if not(all(wV)), error('w''s must be positive integers'); end


% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=max(wV);
N=dom_deg*N;

k=1:N; xC=cos((2*k-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
zAMR=aV(1)*sin(wV(1)*th+phiV(1));
zAMI=aV(2)*sin(wV(2)*th+phiV(2));
zAM=zAMR+i*zAMI;

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.









% ............................ RHODONEA ..................................

function  [zAM,C]=complex_rhodonea_AM(a,k,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by rhodonea curve.
%         z(t)=a*cos(k*t).*exp(i*t);
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a,k: parameters defining the domain, with
%                     z(t)=a*cos(k*t)*exp(i*t),   t in [0,2*pi]
%      with wV vector of positive integers.
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 23, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

if (ceil(k)-k) > 0, error('k must be positive integer'); end
if not(a > 0), error('a must be a positive integer'); end
if not(k > 0), error('k must be a positive integer'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=k+1;
N=dom_deg*N;

k1=1:N; xC=cos((2*k1-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
% zAMR=a*cos(k*th).*cos(th);
% zAMI=a*cos(k*th).*sin(th);
zAM=a*cos(k*th).*exp(i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.








% ............................ HABENICHT CLOVER ...........................

function  [zAM,C]=complex_habenicht_clover_AM(n,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by an "habenicht_clover"
% curve.
% Equation:
%       z(t)=(1+cos(n*t)+(sin(n*t)).^2).*exp(i*t);
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% n: parameter defining the domain, with
%          z(t)=(1+cos(n*t)+(sin(n*t))^2).*exp(i*t),  t in [0,2*pi]
%      with "n > 0" integer; e.g. choose "n=3"
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 24, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 3, m=8; end

if not(n > 0), error('n must be a positive integer'); end
if not(n == floor(n)), error('n must be a positive integer'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=2*n+1;
N=dom_deg*N;

k1=1:N; xC=cos((2*k1-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
% zAMR=a*cos(k*th).*cos(th);
% zAMI=a*cos(k*th).*sin(th);
zAM=(1+cos(n*th)+(sin(n*th)).^2).*exp(i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.







% ............................ EGG ...........................

function  [zAM,C]=complex_egg_AM(a,n,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by an "egg" curve.
% Equation:
%           z(t)=a*((cos(t)).^n).*exp(i*t);
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% n: parameter defining the domain, with
%          z(t)=a*(cos(t))^n).*exp(i*t),  t in [0,2*pi]
%      with "n > 0" integer; e.g. choose "n=3"
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% INFO:
%--------------------------------------------------------------------------
% https://mathcurve.com/courbes2d/courbes2d.shtml
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 24, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 4, m=8; end

if not(n > 0), error('n must be a positive integer'); end
if not(n == floor(n)), error('n must be a positive integer'); end

% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=n+1;
N=dom_deg*N;

k1=1:N; xC=cos((2*k1-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
% zAMR=a*cos(k*th).*cos(th);
% zAMI=a*cos(k*th).*sin(th);
zAM=a*((cos(th)).^n).*exp(i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.







% ............................ BIFOLIUM ...........................

function  [zAM,C]=complex_bifolium_AM(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by an "bifolium" curve,
%               z(t)=cos(t)*(sin(t))^2).*exp(i*t),  t in [0,2*pi]
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% INFO:
%--------------------------------------------------------------------------
% https://mathcurve.com/courbes2d/courbes2d.shtml
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 24, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 2, m=8; end


% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=4;
N=dom_deg*N;

k1=1:N; xC=cos((2*k1-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
% zAMR=a*cos(k*th).*cos(th);
% zAMI=a*cos(k*th).*sin(th);
zAM=cos(th).*((sin(th)).^2).*exp(i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.







% ............................ BIFOLIUM ...........................

function  [zAM,C]=complex_torpedo_AM(a,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg*m".
%
% Domain: complex domain whose boundary is defined by an "torpedo" curve,
%               z(t)=z(t)=a*cos(t).*cos(2*t).*exp(i*t),  t in [0,2*pi]
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% a: parameter defining the domain;
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% zAM: vector of complex numbers (elements of the AM)
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% INFO:
%--------------------------------------------------------------------------
% https://mathcurve.com/courbes2d/courbes2d.shtml
% The curve is also known as "right trifolium".
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 25, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 3, m=8; end


% Building reference AM on sides.
N=2*m*deg; % card AM

% This factor is due to the fact that the domain is parametrically
% described by trigonometric polynomials of degree "dom_deg".
dom_deg=4;
N=dom_deg*N;

k1=1:N; xC=cos((2*k1-1)*pi/(2*N)); % cheb. reference points on [-1,1]

tha=-pi; thb=pi;

thR=2*asin(xC'*sin((thb-tha)/4))+(thb+tha)/2;
th=pi+thR;

% Mapping the AM to the domain, "th" in [0,2*pi]
% zAMR=a*cos(k*th).*cos(th);
% zAMI=a*cos(k*th).*sin(th);
zAM=a*cos(th).*cos(2*th).*exp(i*th);

% AM constant in norming set inequality.
C=1/cos(pi/(2*m)); % Trigonometric constant.




