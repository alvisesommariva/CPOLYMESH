
function demo_approximation

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% The purpose of this demo is to show how to evaluate the quality of
% interpolation / least-squares approximation of an analytic function over
% some subregions of the complex plane.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% L. Leokadia Białas-Cież,
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 7, 2023
%--------------------------------------------------------------------------
%
% Domain: the variable "domain_example" defines the following domains
%
%      +1: 'sun'  
%      +2: 'polygon' 
%      +3: 'cardioid' 
%      +4: 'curvpolygon' 
%      +5: 'uniondisks' 
%      +6: 'lune' 
%      +7: 'hypocycloid'; (wide region)
%      +8: 'epicycloid'; (wide region)
%      +9: 'epitrochoid'; (wide region)
%     -10: 'limacon'; 
%     -11: 'ellipse'; 
%     *12: 'lissajous'; (not available)
%     +13: 'deltoid' 
%     +14: 'rhodonea' 
%     +15: 'habenicht_clover';
%     +16: 'egg'
%     +17: 'bifolium'
%     +18: 'torpedo' 
%
%--------------------------------------------------------------------------

domain_example=3;

% Degree: "degV" is a vector of interpolation/approximation degrees.
degV=2:2:30; 

% Pointset: leja=0 AFP, leja=1 DLP, leja=2 PLP, leja=3 LS.
leja=0; 

% Define function.
f=@(z) sin(z); 

% Make experiment.
[ae,re]=demo_approximation_test(domain_example,degV,leja,f);








function [ae,re]=demo_approximation_test(domain_example,degV,leja,f)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% The purpose of this demo is to show how to evaluate the quality of
% interpolation / least-squares approximation of an analytic function over
% some subregions of the complex plane.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% L. Leokadia Białas-Cież,
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 7, 2023
%--------------------------------------------------------------------------

% Domain: the variable "domain_example" defines the following domains
%
%      +1: 'sun'  
%      +2: 'polygon' 
%      +3: 'cardioid' 
%      +4: 'curvpolygon' 
%      +5: 'uniondisks' 
%      +6: 'lune' 
%      +7: 'hypocycloid'; (wide region)
%      +8: 'epicycloid'; (wide region)
%      +9: 'epitrochoid'; (wide region)
%     -10: 'limacon'; 
%     -11: 'ellipse'; 
%     *12: 'lissajous'; (not available)
%     +13: 'deltoid' 
%     +14: 'rhodonea' 
%     +15: 'habenicht_clover';
%     +16: 'egg'
%     +17: 'bifolium'
%     +18: 'torpedo' 


% ......................... Defaults  ..............................

if nargin < 1, domain_example=13; end

% Degree: "degV" is a vector of interpolation/approximation degrees.
if nargin < 2, degV=2:2:30; end

% Pointset: leja=0 AFP, leja=1 DLP, leja=2 PLP, leja=3 LS.
if nargin < 3, leja=3; end

% Define function
if nargin < 4, f=@(z) sin(z); end



% ......................... Special settings  .......................

% Plot of the pointset for the last degree analysed and the test set.
do_plot=1; % 0: no plot, 1: plot

% The higher "deg_target", the higher the cardinality of the test set.
deg_target=10;

% ......................... Main code below  ..............................

% Define "domain".
domain=define_domain(domain_example);
if domain_example == 12,fprintf(2,'\n \t Domain not suitable \n');return;end

% Disk enclosing region (useful to shift/scale monomial basis, for healing
% ill-conditioning)
[~,~,domain]=disk_enclosing_region(domain);

% Define a dense set of "test points".
targets=test_points(domain,deg_target,4);

fval_targets=feval(f,targets);

fprintf('\n  \t  .................. statistics  .................... \n');

fprintf('\n \t Domain  : '); fprintf(domain.name);

switch leja
    case 0
        leja_str='Approximate Fekete Points';
    case 1
        leja_str='Discrete Leja Points';
    case 2
        leja_str='Pseudo Leja Points';
    case 3
        leja_str='Least-Squares';
end

fprintf('\n \t Pointset: '); fprintf(leja_str);
fprintf('\n \t Cardinality target points: %10.0f',length(targets));
fprintf('\n \t Max abs val f(z): %1.3e \n',norm(fval_targets,inf));

fprintf('\n  \t ........... approximation errors  ................. \n');
ae=[]; re=[];
for deg=degV
    [pts,~,domain]=interp_pointset(domain,leja,deg);
    fval_pts=feval(f,pts);
    [~,pval_targets] = cwamfit(deg,pts,targets,fval_pts,domain);
    ae_arg=fval_targets-pval_targets;
    ae(end+1)=norm(ae_arg,inf);
    re_arg=(fval_targets-pval_targets)./(fval_targets+(fval_targets == 0));
    re(end+1)=norm(re_arg,inf);
    fprintf('\n \t deg: %3.0f abs.err.: %1.3e rel.err.: %1.3e',...
        deg,ae(end),re(end));
end
fprintf('\n  \t ..................................................... \n');


% Plot figure
figure(1)
plot(real(targets),imag(targets),'k.'); 
hold on; 
axis equal; 
plot(real(pts),imag(pts),'go','MarkerEdgeColor','k',...
                       'MarkerFaceColor','g',...
                       'MarkerSize',10)
hold off;




