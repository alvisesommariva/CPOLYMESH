function DOP = cwamdopeval(deg,R1,R2,pts,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% The routine computes the Vandermonde matrix of degree deg at the points 
% "pts" in a discrete orthogonal polynomial basis, depending on "R1" and 
% "R2".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% R1, R2: matrices of change of basis, w.r.t a certain shifted monomial 
%    basis;
% pts: interpolation/least square points;
% domain: domain structure (dependent on the domain, see "define_domain.m").
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% DOP: a generalized Vandermonde matrix w.r.t. discrete orthogonal 
%      polynomials of degree "deg" evaluated at "pts".
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014,
% Adapted to complex case: October 2023,
% Modified: November 7, 2023.
%--------------------------------------------------------------------------

W=gen_vandermonde_matrix(pts,deg,domain.zC,domain.zR);
DOP=(W/R1)/R2;