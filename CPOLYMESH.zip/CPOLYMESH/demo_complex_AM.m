
function demo_complex_AM(example,deg)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% The purpose of this demo is to show how to define Admissible Meshes (AM)
% over many subregions of the complex plane.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
%    
% example: the variable defines the following domains
%
%     example 1: 'sun';
%     example 2: 'polygon';
%     example 3: 'cardioid';
%     example 4: 'curvpolygon';
%     example 5: 'uniondisks';
%     example 6: 'lune';
%     example 7: 'hypocycloid';
%     example 8: 'epicycloid';
%     example 9: 'epitrochoid';
%     example 10: 'limacon';
%     example 11: 'ellipse';
%     example 12: 'lissajous';
%     example 13: 'deltoid'
%     example 14: 'rhodonea'
%     example 15: 'habenicht_clover';
%     example 16: 'egg'
%     example 17: 'bifolium'
%     example 18: 'torpedo'
%
% deg: Admissible Mesh degree
%
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% L. Leokadia Białas-Cież,
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 4, 2023
%--------------------------------------------------------------------------

if nargin < 1, example=3; end
if nargin < 2, deg=5; end

% SETTINGS.
domain=define_domain(example); % Definition of structure of the domains above
m=2;    % Parameter to define suitable AMs. The higher, the larger the AM.

% COMPUTING ADMISSIBLE MESH.
[zAM,C]=complex_AM(domain,deg,m); % Compute AM

% COMPUTING APPROXIMATION OF THE LEAST-SQUARES LEBESGUE CONSTANT.
leb_constant=evaluate_leb_const(domain,zAM,deg,m);

% STATISTICS.
fprintf('\n \t ............ Lebesgue constant ...............\n \n ');

fprintf('\t Complex plane set: '); disp(domain.name)
fprintf('\n \n \t Degree              : %4.0f',deg);
fprintf('\n \t Cardinality AM      : %8.0f',length(zAM));
fprintf('\n \t Lebesgue Constant AM: %1.5e',leb_constant(1));
fprintf('\n \t .............................................. ');
fprintf('\n \t See figure, representing the Admissible Mesh');
fprintf('\n \t .............................................. \n \n');

% PLOT AM.

% Plotting AM points
plot(real(zAM),imag(zAM),'o','MarkerEdgeColor','k',...
                       'MarkerFaceColor','g',...
                       'MarkerSize',4);
hold on;
axis equal;
hold off;




