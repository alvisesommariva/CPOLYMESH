
function [zC,zR,domain]=disk_enclosing_region(structure)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% It computes the center "zC" and the radius "zR" of a disk approximatively
% containing the domain.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% structure: The value of structure can be:
% * domain passed as structure (see "define_domain" for details),
% * a vector of complex values representing the AM.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% zC,zR: center and radius of a disk approximatively containing the domain.
% domain: it includes information about zC and zR.
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: November 2, 2023
%--------------------------------------------------------------------------

if isstruct(structure) % the variable is "domain"
    domain=structure;
    if not(isfield(domain,'zC') & isfield(domain,'zR'))
        zAM=complex_AM(domain,10,4);
        zC=mean(zAM); zR=max(abs(zAM-zC));
    else
        zC=domain.zC; zR=domain.zR;
    end
else % the variable is a vector (AM)
    zAM=structure;
    zC=mean(zAM);
    zR=max(abs(zAM-zC));
end

domain.zC=zC; domain.zR=zR;


