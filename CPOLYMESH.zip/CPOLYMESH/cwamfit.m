
function [cfs,lsp] = cwamfit(deg,wam,pts,fval,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% The routine computes the coefficients 
% * the coefficients "cfs" of the polynomial approximant/interpolant of 
%   degree "deg" at "wam" (relatively to a certain fixed polynomial basis);
% * if required, it evaluates this polynomial at "pts".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% wam: vector of complex data; 
%     if "length(wam)=deg+1" then interpolation will coefficients "cfs" 
%     (w.r.t. a certain orthonormal basis (w.r.t. a discrete measure). 
% pts: interpolation/least square points;
% fval: samples at "wam".
% domain: domain structure (dependent on the domain, see "define_domain.m").
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% cfs: the coefficients "cfs" of the polynomial approximant/interpolant of 
%   degree "deg" at "wam" (relatively to a certain fixed polynomial basis);
% lsp: evaluation of the polynomial interpolant/approximant at "pts".
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014,
% Adapted to complex case: October 2023,
% Modified: November 7, 2023.
%--------------------------------------------------------------------------

[Q,R1,R2] = cwamdop(deg,wam,domain);
cfs=Q'*fval;

if nargout > 1
    DOP=cwamdopeval(deg,R1,R2,pts,domain);
    lsp=DOP*cfs;
end
