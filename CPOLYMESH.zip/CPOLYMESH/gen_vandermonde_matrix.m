
function V=gen_vandermonde_matrix(pts,deg,zC,zR)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Computation of a generalised Vandermonde matrix (fighting ill condition)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% pts: pointset of complex numbers
% zC, zR: center and radius of a small disk containing the domain.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% V: generalised Vandermonde matrix
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 19, 2023 (by A. Sommariva).
% Modified on October 19, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise 
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% L. Leokadia Białas-Cież, 
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 1, 2023
%--------------------------------------------------------------------------


if nargin < 3, zC=0; end
if nargin < 4, zR=1; end

% Shifted monomial basis (w.r.t. the complex disk with center zC and radius
% zR).

pts_sh=(pts-zC)/zR;
V=[]; % Vandermonde matrix at zAM (dims: points x polynomial dim)
for k=0:deg, VL=pts_sh.^k; V=[V VL]; end
