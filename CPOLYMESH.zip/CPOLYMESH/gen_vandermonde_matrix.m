
function V=gen_vandermonde_matrix(pts,deg,zC,zR)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Computation of a generalised Vandermonde matrix (fighting ill condition)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% pts: pointset of complex numbers
% zC, zR: center and radius of a small disk containing the domain.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% V: generalised Vandermonde matrix
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 19, 2023 (by A. Sommariva).
% Modified on October 19, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if nargin < 3, zC=0; end
if nargin < 4, zR=1; end

% Shifted monomial basis (w.r.t. the complex disk with center zC and radius
% zR).

pts_sh=(pts-zC)/zR;
V=[]; % Vandermonde matrix at zAM (dims: points x polynomial dim)
for k=0:deg, VL=pts_sh.^k; V=[V VL]; end
