READ ME:

To run the demo, just type in the Matlab shell "demo_complex_driver" with values ranging from 1 to 6.

Example in the Matlab shell: 

>> demo_complex_driver(6)

and press ENTER.

