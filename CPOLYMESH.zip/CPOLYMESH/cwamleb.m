function leb = cwamleb(deg,pts,cmesh,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes the Lebesgue constant of least-squares polynomial fitting
% on "pts", using the control mesh "cmesh".
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
%--------------------------------------------------------------------------

[Q,R1,R2]=cwamdop(deg,pts,domain);
DOP=cwamdopeval(deg,R1,R2,cmesh,domain);
leb=norm(Q*DOP',1);
