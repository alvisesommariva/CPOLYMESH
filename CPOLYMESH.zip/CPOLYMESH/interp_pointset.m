
function [pts,zAM]=interp_pointset(domain,leja,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Interpolation pointset at degree "deg".
% The pointset can be of AFEK, DLP or PLP type depending on "leja" parm.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: domain structure (dependent on the domain, see "define_domain.m");
% leja: 0: AFEK, 1: DLP, 2: PLP;
% deg: interpolation degree;
% m: positive integer for computing the Lebesgue constant; the higher than
%    is the most precise but also more time consuming (use, e.g. m=4);
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% pts: interpolation pointset for this domain at degree deg;
% zAM: admissible mesh for this domain at degree deg.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------


% 1. Define defaults.
if nargin < 2, leja=0; end
if nargin < 3, deg=20; end
if nargin < 4, m=4; end

% 2. Compute interpolation pointset.

zAM=[];

switch leja

    case {0,1} % 0: approximate Fekete points, 1: discrete Leja points

        zAM=complex_AM(domain,deg,m);

        zC=domain.zC; zR=domain.zR; % disk including the domain (center,
        % radius)

        %         zAM_sh=(zAM-zC)/zR;
        %         % Vandermonde matrix at zAM (dims: points x polynomial dim)
        %         V=[]; for k=0:deg, VAML=zAM_sh.^k; V=[V VAML]; end
        %         
        V=gen_vandermonde_matrix(zAM,deg,zC,zR);
        [Q1,R1]=qr(V,0);[Q,R2]=qr(V/R1,0);

        dim=deg+1;

        if leja == 0 % Approximate Fekete Points
            w=Q'\ones(dim,1);
            ind=find(abs(w)>0);
            pts=zAM(ind,:);
        else % Discrete Leja points
            [L,U,perm]=lu(Q,'vector');
            pts=zAM(perm(1:dim),:);
        end


    otherwise % Pseudo Leja points

        pts_trial=complex_AM(domain,1,m);
        [val,index]=max(imag(pts_trial));
        pts=pts_trial(index);
        for degL=1:deg
            pts_trial=complex_AM(domain,degL,m);
            pts_L=choose_next_point(pts,pts_trial);
            pts(end+1,1)=pts_L;
        end

end





function pt=choose_next_point(pts,pts_trial)

% Computing next pseudo Leja point "pt" from a previous set "pts" using
% points in "pts_trial".

prods=ones(size(pts_trial));
for k=1:length(pts)
    z_minus_zk=pts_trial-pts(k);
    prods=prods.*z_minus_zk;
end

[M,ind]=max(abs(prods));
pt=pts_trial(ind);

