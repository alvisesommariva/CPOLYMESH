
function [leb_constant,pts,zAM,REUB]=demo_complex(domain,leja,deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo on computing Lebesgue constant via AM.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain: domain structure (dependent on the domain, see "define_domain.m");
% leja: 0: afek, 1: discrete Leja, 2: pseudo Leja, 3: LS over AM
% deg: Interpolation degree;
% m: admissible mesh "m" factor (linked to Lebesgue constant estimate)
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% leb_constant: Lebesgue constant of interpolation set,
% -> leb_constant(1): rough approximation,
% -> leb_constant(2): fine approximation;
% pts: interpolation pointset for this domain at degree deg;
% zAM: admissible mesh for this domain at degree deg;
% REUB: Lebesgue constant relative error upper bound;
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on October 18, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% L. Leokadia Białas-Cież,
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 1, 2023
%--------------------------------------------------------------------------

if nargin < 1, domain=define_domain(2); end

% Choose between 0: AFEK, 1: discrete Leja, 2: pseudo Leja points
if nargin < 2, leja=0; end

% Interpolation degree.
if nargin< 3, deg=20; end

% Admissible mesh "m" factor (linked to Lebesgue constant estimate)
% The higher the better estimate but also more time consuming.
if nargin< 4, m=8; end




% ........................ MAIN CODE BELOW  ........................

% 1. DEFINE SET (Interpolation or Least-Squares)
if leja < 3
    [pts,zAM,domain]=interp_pointset(domain,leja,deg,m);
else
    [zAM,C,domain]=complex_AM(domain,deg,m);
    pts=zAM;
end

% 2. EVALUATING LEBESGUE CONSTANTS

% AM approach
[leb_constant(1),zAM,C]=evaluate_leb_const(domain,pts,deg,m);

% higher AM approach
mH=10*m;
[leb_constant(2),zAMH,CH]=evaluate_leb_const(domain,pts,deg,mH);


% 3. WRITE STATISTICS.

AE=abs(leb_constant(2)-leb_constant(1)); % errors
RE=AE/abs(leb_constant(2));
REUB=C-1; % error constants
REUBH=CH-1;

fprintf('\n \t ............ Lebesgue constant ...............\n \n ');

fprintf('\t Complex plane set: '); disp(domain.name)

switch leja
    case 0
        fprintf('\n \t Pointset: AFEK');
    case 1
        fprintf('\n \t Pointset: DLP');
    case 2
        fprintf('\n \t Pointset: PLP');
    case 3
        fprintf('\n \t Pointset: AM (Least-Squares)');
end
fprintf('\n \n \t Degree: %4.0f \n',deg);
fprintf('\n \t Lebesgue Constant AM: %1.5e',leb_constant(1));
fprintf('\n \t Lebesgue Const. HAM : %1.5e',leb_constant(2));
fprintf('\n \n \t Absolute error      : %1.5e',AE);
fprintf('\n \t Relative error      : %1.5e',RE);
fprintf('\n \t Relative err. est.  : %1.5e',REUB);
fprintf('\n \t Relative err. est. H: %1.5e',REUBH);
fprintf('\n \n \t Card. admiss. mesh  : %5.0f',max(size(zAM)));
fprintf('\n \t Card. high ad. mesh : %5.0f',max(size(zAMH)));
fprintf('\n \t m degree            : %5.0f',m);
fprintf('\n \t m degree H          : %5.0f',mH);
fprintf('\n \t .............................................. \n \n');
